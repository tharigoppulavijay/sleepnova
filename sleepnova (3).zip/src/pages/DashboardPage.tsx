import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  CheckCircle2,
  Clock,
  FileSpreadsheet,
  Info,
  Moon,
  PlusCircle,
} from 'lucide-react';
import { formatDisplayDate, formatMinutes, sleepApi } from '../api/client';
import { SleepChart } from '../components/SleepChart';
import type { AppRoute, ExecutiveSummary, SleepRecord, SleepSettings } from '../types/sleep';

interface DashboardPageProps {
  onNavigate: (route: AppRoute) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const [summary, setSummary] = useState<ExecutiveSummary | null>(null);
  const [recentRecords, setRecentRecords] = useState<SleepRecord[]>([]);
  const [settings, setSettings] = useState<SleepSettings | null>(null);
  const [recoveryNotice, setRecoveryNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sumRes, recRes, setRes] = await Promise.all([
        sleepApi.getSummary(),
        sleepApi.listRecords({ page: 1, page_size: 6, sort: 'newest' }),
        sleepApi.getSettings(),
      ]);
      setSummary(sumRes);
      setRecentRecords(recRes.records);
      setSettings(setRes.settings);
      setRecoveryNotice(recRes.recovery_notice || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load dashboard analytics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const weeklyChartData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const series = summary.weekly.daily_series;
    const goal = summary.weekly.stats.goal_hours;
    return {
      labels: series.map((d) => d.short_day || d.label),
      datasets: [
        {
          label: 'Sleep Duration (hrs)',
          data: series.map((d) => d.duration_hours ?? 0),
          backgroundColor: series.map((d) =>
            !d.has_record
              ? 'rgba(255,255,255,0.04)'
              : (d.duration_hours || 0) >= goal
                ? '#54D9C6'
                : '#9585FF',
          ),
          borderRadius: 6,
          barPercentage: 0.56,
        },
        {
          label: `Goal (${goal}h)`,
          data: series.map(() => goal),
          type: 'line' as const,
          borderColor: 'rgba(197,168,255,0.65)',
          borderDash: [5, 5],
          borderWidth: 1.5,
          pointRadius: 0,
        },
      ],
    };
  }, [summary]);

  const monthlyChartData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const series = summary.monthly.daily_series;
    return {
      labels: series.map((d) => d.label),
      datasets: [
        {
          label: '30-Day Duration (hrs)',
          data: series.map((d) => d.duration_hours),
          borderColor: '#9585FF',
          backgroundColor: 'rgba(149,133,255,0.14)',
          borderWidth: 2,
          tension: 0.3,
          spanGaps: true,
          fill: true,
          pointRadius: 2.5,
          pointBackgroundColor: '#54D9C6',
        },
      ],
    };
  }, [summary]);

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  if (loading) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
        <div className="h-16 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((k) => (
            <div key={k} className="h-32 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] animate-pulse" />
          ))}
        </div>
        <div className="h-80 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] animate-pulse" />
      </div>
    );
  }

  if (error || !summary) {
    return (
      <div className="p-8 rounded-xl bg-[#151D34] border border-red-500/30">
        <h2 className="font-display text-lg font-semibold text-[#F4F5FF] mb-2">
          Dashboard Unavailable
        </h2>
        <p className="text-sm text-[#A0A8C0] mb-4">{error}</p>
        <button
          type="button"
          onClick={loadDashboard}
          className="px-4 py-2 rounded-lg bg-[#9585FF] text-[#080B16] text-sm font-semibold"
        >
          Retry Loading
        </button>
      </div>
    );
  }

  const isEmpty = summary.overall.stats.record_count === 0;
  const overall = summary.overall.stats;
  const weekly = summary.weekly.stats;
  const consistency = summary.overall.consistency;
  const weeklyDelta = summary.weekly.comparison.average_delta_hours;
  const dateFmt = settings?.preferred_date_format || 'YYYY-MM-DD';

  return (
    <div className="space-y-8">
      {/* Top Greeting Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-mono text-[#54D9C6] mb-1.5">{todayFormatted}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
            Good morning, welcome to SleepNova.
          </h1>
          <p className="text-sm text-[#A0A8C0] mt-1.5 max-w-[68ch]">
            All metrics, weekly comparisons, and consistency indicators below are computed directly
            from your stored local CSV and JSON sleep records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('/history')}
            className="px-3.5 py-2 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            View History
          </button>
          <button
            type="button"
            onClick={() => onNavigate('/analytics')}
            className="px-3.5 py-2 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            Explore Analytics
          </button>
          <button
            type="button"
            onClick={() => onNavigate('/reports')}
            className="px-3.5 py-2 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            Generate Report
          </button>
        </div>
      </div>

      {/* Explicit Demonstration Data Disclosure or Recovery Notice */}
      {(recoveryNotice || (summary.data_quality.has_demo_data && settings?.show_demo_banner !== false)) && (
        <div className="px-4 py-3 rounded-xl bg-[#101629] border border-[rgba(149,133,255,0.25)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start sm:items-center gap-2.5 text-[#A0A8C0]">
            <Info className="w-4 h-4 text-[#9585FF] shrink-0 mt-0.5 sm:mt-0" />
            <span>
              {recoveryNotice
                ? recoveryNotice
                : `Demonstration dataset active (${summary.data_quality.demo_records} demo records · ${summary.data_quality.user_records} personal records). Sample entries are clearly labeled and do not represent personal medical records.`}
            </span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('/settings')}
            className="text-[#54D9C6] hover:text-[#F4F5FF] font-medium whitespace-nowrap shrink-0 self-start sm:self-auto"
          >
            Manage Dataset -&gt;
          </button>
        </div>
      )}

      {/* Empty State Onboarding */}
      {isEmpty ? (
        <div className="p-10 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] text-center max-w-2xl mx-auto">
          <Moon className="w-10 h-10 text-[#9585FF] mx-auto mb-4" />
          <h2 className="font-display text-xl font-semibold text-[#F4F5FF] mb-2">
            No sleep records logged yet
          </h2>
          <p className="text-sm text-[#A0A8C0] leading-relaxed mb-6">
            Start by recording your most recent night of sleep, importing an existing CSV log, or
            loading the 39-record demonstration dataset to explore charts and executive summaries.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('/logger')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] text-[#080B16] text-sm font-semibold transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Log First Sleep Record</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                await sleepApi.resetDemo();
                loadDashboard();
              }}
              className="px-5 py-2.5 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-sm font-medium text-[#F4F5FF] transition-colors"
            >
              Load Demonstration Dataset
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* 4 Metric Cards */}
          <section aria-label="Key sleep metrics" className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="text-xs font-medium text-[#A0A8C0] mb-2">Total Sleep Records</p>
              <p className="font-mono text-2xl sm:text-3xl font-semibold tabular-nums text-[#F4F5FF]">
                {overall.record_count} <span className="text-sm font-normal text-[#A0A8C0]">sessions</span>
              </p>
              <p className="text-xs text-[#A0A8C0] mt-2 font-mono tabular-nums">
                Total logged: {overall.total_formatted} ({overall.total_hours.toFixed(1)}h)
              </p>
            </div>

            <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="text-xs font-medium text-[#A0A8C0] mb-2">Average &amp; Weekly Avg</p>
              <p className="font-mono text-2xl sm:text-3xl font-semibold tabular-nums text-[#54D9C6]">
                {overall.average_formatted}
              </p>
              <div className="mt-2 flex items-center gap-1.5 text-xs">
                {weeklyDelta !== null ? (
                  <>
                    {weeklyDelta >= 0 ? (
                      <ArrowUpRight className="w-3.5 h-3.5 text-[#54D9C6]" />
                    ) : (
                      <ArrowDownRight className="w-3.5 h-3.5 text-amber-400" />
                    )}
                    <span className="font-mono tabular-nums text-[#A0A8C0]">
                      7d avg {weekly.average_formatted} ({weeklyDelta >= 0 ? '+' : ''}
                      {weeklyDelta.toFixed(2)}h)
                    </span>
                  </>
                ) : (
                  <span className="font-mono text-[#A0A8C0]">7d avg: {weekly.average_formatted}</span>
                )}
              </div>
            </div>

            <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="text-xs font-medium text-[#A0A8C0] mb-2">Latest Sleep Duration</p>
              <p className="font-mono text-2xl sm:text-3xl font-semibold tabular-nums text-[#9585FF]">
                {summary.daily.latest_session
                  ? formatMinutes(summary.daily.latest_session.duration_minutes)
                  : '—'}
              </p>
              <p className="text-xs text-[#A0A8C0] mt-2 font-mono tabular-nums">
                {summary.daily.latest_session
                  ? `${formatDisplayDate(summary.daily.latest_session.sleep_date, dateFmt)} · ${summary.daily.latest_session.bedtime}->${summary.daily.latest_session.wake_time}`
                  : 'No sessions'}
              </p>
            </div>

            <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="text-xs font-medium text-[#A0A8C0] mb-2">Sleep Goal Progress</p>
              <p className="font-mono text-2xl sm:text-3xl font-semibold tabular-nums text-[#F4F5FF]">
                {weekly.goal_achievement_pct}%{' '}
                <span className="text-sm text-[#A0A8C0] font-normal">this week</span>
              </p>
              <div className="mt-2.5">
                <div className="flex items-center justify-between text-xs text-[#A0A8C0] mb-1">
                  <span>{weekly.record_count} / 7 nights logged</span>
                  <span className="font-mono tabular-nums text-[#C5A8FF]">
                    Target {weekly.goal_hours}h
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-[#080B16] overflow-hidden">
                  <div
                    className="h-full bg-[#54D9C6] rounded-full transition-all"
                    style={{ width: `${Math.min(100, weekly.goal_achievement_pct)}%` }}
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Charts + Consistency Row */}
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
                <div>
                  <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
                    7-Day Sleep Duration Trend
                  </h2>
                  <p className="text-xs text-[#A0A8C0] font-mono tabular-nums mt-0.5">
                    {formatDisplayDate(summary.weekly.period_start, dateFmt)} to{' '}
                    {formatDisplayDate(summary.weekly.period_end, dateFmt)} · Avg{' '}
                    {weekly.average_formatted}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('/analytics')}
                  className="text-xs font-medium text-[#9585FF] hover:text-[#C5A8FF] transition-colors"
                >
                  Full Analytics -&gt;
                </button>
              </div>
              <SleepChart
                type="bar"
                data={weeklyChartData}
                options={{
                  scales: {
                    y: {
                      min: 0,
                      max: 12,
                      title: { display: true, text: 'Hours', color: '#A0A8C0' },
                    },
                  },
                }}
                ariaLabel="Seven-day sleep duration bar chart"
              />
            </div>

            <div className="lg:col-span-4 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] flex flex-col justify-between">
              <div>
                <h2 className="font-display text-base font-semibold text-[#F4F5FF] mb-1">
                  Sleep Consistency Indicator
                </h2>
                <p className="text-xs text-[#A0A8C0] mb-5">
                  Schedule regularity from stored bedtime &amp; wake-up variations
                </p>

                {consistency.sufficient_data ? (
                  <>
                    <div className="flex items-baseline gap-3 mb-4">
                      <span className="font-mono text-4xl font-semibold tabular-nums text-[#9585FF]">
                        {consistency.consistency_score}%
                      </span>
                      <span className="text-sm font-medium text-[#54D9C6]">
                        {consistency.rating_label}
                      </span>
                    </div>

                    <div className="space-y-2.5 py-4 border-y border-[rgba(255,255,255,0.08)] text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-[#A0A8C0]">Mean Bedtime</span>
                        <span className="font-mono tabular-nums text-[#F4F5FF]">
                          {consistency.average_bedtime} (±{consistency.bedtime_stdev_minutes}m)
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[#A0A8C0]">Mean Wake Time</span>
                        <span className="font-mono tabular-nums text-[#F4F5FF]">
                          {consistency.average_wake_time} (±{consistency.wake_stdev_minutes}m)
                        </span>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-[#A0A8C0] py-4">{consistency.explanation}</p>
                )}
              </div>

              <p className="text-xs text-[#A0A8C0] leading-relaxed mt-4">
                {consistency.explanation}
              </p>
            </div>
          </section>

          {/* Monthly Overview + Threshold Warnings */}
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
                <div>
                  <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
                    30-Day Monthly Overview
                  </h2>
                  <p className="text-xs text-[#A0A8C0] font-mono tabular-nums mt-0.5">
                    {summary.monthly.stats.record_count} recorded sessions · Avg{' '}
                    {summary.monthly.stats.average_formatted}
                  </p>
                </div>
                <span className="text-xs font-mono text-[#54D9C6]">
                  {summary.trend.status}
                </span>
              </div>
              <SleepChart
                type="line"
                data={monthlyChartData}
                options={{
                  scales: {
                    y: {
                      min: 0,
                      max: 13,
                    },
                  },
                }}
                heightClass="h-64"
                ariaLabel="Thirty-day monthly sleep duration line chart"
              />
            </div>

            <div className="lg:col-span-5 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <div className="flex items-center justify-between gap-2 mb-4">
                <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
                  Threshold Indicators
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('/settings')}
                  className="text-xs text-[#A0A8C0] hover:text-[#F4F5FF] transition-colors"
                >
                  Configure
                </button>
              </div>
              <div className="space-y-3">
                {summary.warnings.map((w) => {
                  const Icon =
                    w.severity === 'warning'
                      ? AlertTriangle
                      : w.severity === 'nominal'
                        ? CheckCircle2
                        : Info;
                  const iconColor =
                    w.severity === 'warning'
                      ? 'text-amber-400'
                      : w.severity === 'nominal'
                        ? 'text-[#54D9C6]'
                        : 'text-[#9585FF]';
                  return (
                    <div
                      key={w.id}
                      className="p-3.5 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)] flex items-start gap-3"
                    >
                      <Icon className={`w-4 h-4 shrink-0 mt-0.5 ${iconColor}`} />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[#F4F5FF]">{w.title}</p>
                        <p className="text-xs text-[#A0A8C0] mt-1 leading-relaxed">{w.message}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* Personalized Informational Insights */}
          {summary.insights && summary.insights.length > 0 && (
            <section aria-label="Personalized informational insights" className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {summary.insights.map((ins) => (
                <div
                  key={ins.title}
                  className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]"
                >
                  <p className="text-xs font-semibold text-[#C5A8FF] mb-1.5">{ins.title}</p>
                  <p className="text-xs text-[#A0A8C0] leading-relaxed">{ins.detail}</p>
                </div>
              ))}
            </section>
          )}

          {/* Recent Activity + Quick Actions */}
          <section className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
              <div>
                <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
                  Recent Sleep Activity
                </h2>
                <p className="text-xs text-[#A0A8C0] mt-0.5">
                  Latest persisted entries from JSON and CSV storage
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('/logger')}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#9585FF] hover:text-[#C5A8FF]"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Add Entry</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('/history')}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#54D9C6] hover:text-[#F4F5FF]"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>All Records</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[rgba(255,255,255,0.08)] text-xs text-[#A0A8C0]">
                    <th className="py-2.5 pr-4 font-medium">Sleep Date</th>
                    <th className="py-2.5 px-4 font-medium">Bedtime</th>
                    <th className="py-2.5 px-4 font-medium">Wake-up</th>
                    <th className="py-2.5 px-4 font-medium text-right">Duration</th>
                    <th className="py-2.5 pl-4 font-medium">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[rgba(255,255,255,0.06)] text-sm">
                  {recentRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-[#1B2440]/50 transition-colors">
                      <td className="py-3 pr-4 font-mono text-xs tabular-nums text-[#F4F5FF] whitespace-nowrap">
                        {formatDisplayDate(rec.sleep_date, dateFmt)}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs tabular-nums text-[#A0A8C0]">
                        {rec.bedtime}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs tabular-nums text-[#A0A8C0] whitespace-nowrap">
                        {rec.wake_time} ({formatDisplayDate(rec.wake_date, dateFmt)})
                      </td>
                      <td className="py-3 px-4 font-mono text-xs font-semibold tabular-nums text-right text-[#54D9C6] whitespace-nowrap">
                        {formatMinutes(rec.duration_minutes)}
                      </td>
                      <td className="py-3 pl-4 text-xs text-[#A0A8C0] max-w-xs truncate">
                        {rec.notes || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Quick Action Footer Links */}
            <div className="mt-5 pt-4 border-t border-[rgba(255,255,255,0.08)] flex flex-wrap items-center gap-4 text-xs">
              <button
                type="button"
                onClick={() => onNavigate('/analytics')}
                className="inline-flex items-center gap-1.5 text-[#A0A8C0] hover:text-[#F4F5FF]"
              >
                <BarChart3 className="w-3.5 h-3.5 text-[#9585FF]" />
                <span>Inspect 5 Analytical Charts</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('/reports')}
                className="inline-flex items-center gap-1.5 text-[#A0A8C0] hover:text-[#F4F5FF]"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-[#54D9C6]" />
                <span>Export Executive Reports (CSV, JSON, MD, TXT, PNG)</span>
              </button>
            </div>
          </section>
        </>
      )}
    </div>
  );
};
