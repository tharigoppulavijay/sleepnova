import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Download,
  Edit3,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { formatDisplayDate, formatMinutes, sleepApi } from '../api/client';
import type { ImportCsvResult, SleepRecord, SleepSettings } from '../types/sleep';

interface HistoryPageProps {
  onEditRecord: (record: SleepRecord) => void;
}

const SAMPLE_TEST_CSV = `sleep_date,bedtime,wake_date,wake_time,notes
2026-10-01,22:45,2026-10-02,06:30,Valid overnight record for import test
2026-10-02,10:15 PM,2026-10-03,6:45 AM,Valid 12-hour format record
2026-10-01,22:45,2026-10-02,06:30,Duplicate row that should be rejected
2026-13-40,22:00,2026-10-05,06:00,Invalid calendar date month 13
2026-10-05,25:99,2026-10-06,07:00,Invalid bedtime hour 25
2026-10-06,23:00,2026-10-06,06:00,Negative duration (wake before sleep)
2026-10-07,07:00,2026-10-07,07:00,Zero duration record`;

export const HistoryPage: React.FC<HistoryPageProps> = ({ onEditRecord }) => {
  const [records, setRecords] = useState<SleepRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [settings, setSettings] = useState<SleepSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Python-backed filter state
  const [keyword, setKeyword] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minHours, setMinHours] = useState('');
  const [sortOrder, setSortOrder] = useState('newest');

  // Delete confirmation modal
  const [deleteTarget, setDeleteTarget] = useState<SleepRecord | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Bulk CSV import modal
  const [importOpen, setImportOpen] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [csvText, setCsvText] = useState('');
  const [importResult, setImportResult] = useState<ImportCsvResult | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [res, setRes] = await Promise.all([
        sleepApi.listRecords({
          keyword,
          start_date: startDate,
          end_date: endDate,
          min_hours: minHours,
          sort: sortOrder,
          page,
          page_size: 10,
        }),
        sleepApi.getSettings(),
      ]);
      setRecords(res.records);
      setTotal(res.total);
      setTotalPages(res.total_pages);
      setSettings(setRes.settings);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to query sleep records.');
    } finally {
      setLoading(false);
    }
  }, [keyword, startDate, endDate, minHours, sortOrder, page]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  const handleConfirmDelete = async () => {
    if (!deleteTarget || deleting) return;
    setDeleting(true);
    try {
      await sleepApi.deleteRecord(deleteTarget.id);
      setDeleteTarget(null);
      await fetchRecords();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete record.');
    } finally {
      setDeleting(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImportResult(null);
    setImportError(null);

    if (!file.name.toLowerCase().endsWith('.csv')) {
      setSelectedFileName(null);
      setImportError('Only .csv files are supported for bulk import.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setSelectedFileName(null);
      setImportError('CSV file exceeds the 2 MB maximum upload limit.');
      return;
    }

    try {
      const text = await file.text();
      setSelectedFileName(file.name);
      setCsvText(text);
    } catch {
      setImportError('Unable to read the selected CSV file.');
    }
  };

  const handleRunImport = async () => {
    if (importing) return;
    if (!csvText.trim()) {
      setImportError('Please select a CSV file or paste CSV content first.');
      return;
    }
    setImporting(true);
    setImportError(null);
    setImportResult(null);
    try {
      const res = await sleepApi.importCsv(csvText);
      setImportResult(res);
      await fetchRecords();
    } catch (err) {
      setImportError(err instanceof Error ? err.message : 'CSV import failed.');
    } finally {
      setImporting(false);
    }
  };

  const hasActiveFilters = Boolean(keyword || startDate || endDate || minHours);

  const dateFmt = settings?.preferred_date_format || 'YYYY-MM-DD';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
            Sleep History &amp; Search
          </h1>
          <p className="text-sm text-[#A0A8C0] mt-1">
            Query, filter, paginate, and bulk-import sleep records via the Python storage engine.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              setImportOpen(true);
              setImportResult(null);
              setImportError(null);
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5 text-[#9585FF]" />
            <span>Bulk CSV Import</span>
          </button>
          <a
            href="/api/export/csv"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-[#54D9C6]" />
            <span>CSV</span>
          </a>
          <a
            href="/api/export/json"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-[#C5A8FF]" />
            <span>JSON</span>
          </a>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        <div className="lg:col-span-2 relative">
          <Search className="w-4 h-4 text-[#A0A8C0] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={keyword}
            onChange={(e) => {
              setKeyword(e.target.value);
              setPage(1);
            }}
            placeholder="Search ID, date, or notes..."
            aria-label="Search sleep records"
            className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-xs text-[#F4F5FF] placeholder:text-[#A0A8C0]/50 focus:border-[#9585FF] focus:outline-none"
          />
        </div>

        <div>
          <input
            type="date"
            value={startDate}
            onChange={(e) => {
              setStartDate(e.target.value);
              setPage(1);
            }}
            aria-label="Filter from sleep date"
            className="w-full px-3 py-2 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-xs font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
          />
        </div>

        <div>
          <input
            type="date"
            value={endDate}
            onChange={(e) => {
              setEndDate(e.target.value);
              setPage(1);
            }}
            aria-label="Filter to sleep date"
            className="w-full px-3 py-2 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-xs font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
          />
        </div>

        <div>
          <select
            value={minHours}
            onChange={(e) => {
              setMinHours(e.target.value);
              setPage(1);
            }}
            aria-label="Minimum duration filter"
            className="w-full px-3 py-2 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-xs text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
          >
            <option value="">All Durations</option>
            <option value="6">6+ hours</option>
            <option value="7">7+ hours</option>
            <option value="8">8+ hours</option>
            <option value="9">9+ hours</option>
          </select>
        </div>

        <div>
          <select
            value={sortOrder}
            onChange={(e) => {
              setSortOrder(e.target.value);
              setPage(1);
            }}
            aria-label="Sort order"
            className="w-full px-3 py-2 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-xs text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="longest">Longest Duration</option>
            <option value="shortest">Shortest Duration</option>
          </select>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-[#151D34] border border-red-400/40 text-xs text-red-300">
          {error}
        </div>
      )}

      {/* Records Table */}
      <div className="rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] overflow-hidden">
        <div className="px-5 py-3.5 border-b border-[rgba(255,255,255,0.08)] flex items-center justify-between text-xs text-[#A0A8C0]">
          <span className="font-mono tabular-nums">{total} matching record(s)</span>
          {(keyword || startDate || endDate || minHours) && (
            <button
              type="button"
              onClick={() => {
                setKeyword('');
                setStartDate('');
                setEndDate('');
                setMinHours('');
                setPage(1);
              }}
              className="text-[#9585FF] hover:text-[#C5A8FF]"
            >
              Reset Filters
            </button>
          )}
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-[#A0A8C0]">Querying Python storage...</div>
        ) : records.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-[#A0A8C0]">
              {hasActiveFilters
                ? 'No sleep records match the active filter criteria.'
                : 'No sleep records are stored yet. Log a night or bulk-import a CSV dataset.'}
            </p>
            {hasActiveFilters ? (
              <button
                type="button"
                onClick={() => {
                  setKeyword('');
                  setStartDate('');
                  setEndDate('');
                  setMinHours('');
                  setPage(1);
                }}
                className="px-3.5 py-1.5 rounded-lg bg-[#1B2440] text-xs font-medium text-[#C5A8FF] hover:text-[#F4F5FF]"
              >
                Reset Filters
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setImportOpen(true);
                  setImportResult(null);
                  setImportError(null);
                }}
                className="px-3.5 py-1.5 rounded-lg bg-[#1B2440] text-xs font-medium text-[#54D9C6] hover:text-[#F4F5FF]"
              >
                Bulk CSV Import
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[rgba(255,255,255,0.08)] text-xs text-[#A0A8C0] bg-[#101629]/60">
                  <th className="py-3 px-4 font-medium">Record ID</th>
                  <th className="py-3 px-4 font-medium">Sleep Date</th>
                  <th className="py-3 px-4 font-medium">Bedtime</th>
                  <th className="py-3 px-4 font-medium">Wake-up</th>
                  <th className="py-3 px-4 font-medium text-right">Duration</th>
                  <th className="py-3 px-4 font-medium">Notes</th>
                  <th className="py-3 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[rgba(255,255,255,0.06)] text-xs">
                {records.map((rec) => (
                  <tr key={rec.id} className="hover:bg-[#1B2440]/50 transition-colors">
                    <td className="py-3 px-4 font-mono tabular-nums text-[#C5A8FF] whitespace-nowrap">
                      {rec.id}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-[#F4F5FF] whitespace-nowrap">
                      {formatDisplayDate(rec.sleep_date, dateFmt)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-[#A0A8C0]">
                      {rec.bedtime}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-[#A0A8C0] whitespace-nowrap">
                      {rec.wake_time} · {formatDisplayDate(rec.wake_date, dateFmt)}
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold tabular-nums text-right text-[#54D9C6] whitespace-nowrap">
                      {formatMinutes(rec.duration_minutes)}
                    </td>
                    <td className="py-3 px-4 text-[#A0A8C0] max-w-[260px] truncate">
                      {rec.notes || '—'}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onEditRecord(rec)}
                        aria-label={`Edit ${rec.id}`}
                        className="inline-flex p-1.5 rounded-md text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#1B2440] mr-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget(rec)}
                        aria-label={`Delete ${rec.id}`}
                        className="inline-flex p-1.5 rounded-md text-[#A0A8C0] hover:text-red-400 hover:bg-[#1B2440]"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-5 py-3 border-t border-[rgba(255,255,255,0.08)] flex items-center justify-between text-xs text-[#A0A8C0]">
            <span className="font-mono tabular-nums">
              Page {page} of {totalPages}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-[#101629] border border-[rgba(255,255,255,0.08)] disabled:opacity-40 hover:text-[#F4F5FF]"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>
              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-[#101629] border border-[rgba(255,255,255,0.08)] disabled:opacity-40 hover:text-[#F4F5FF]"
              >
                <span>Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-modal-title"
            className="w-full max-w-md p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.12)] shadow-2xl"
          >
            <h2 id="delete-modal-title" className="font-display text-lg font-semibold text-[#F4F5FF] mb-2">
              Delete Sleep Record?
            </h2>
            <p className="text-sm text-[#A0A8C0] mb-5">
              This will permanently remove <span className="font-mono text-[#F4F5FF]">{deleteTarget.id}</span> ({deleteTarget.sleep_date},{' '}
              {formatMinutes(deleteTarget.duration_minutes)}) from local JSON and CSV storage.
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                disabled={deleting}
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-lg bg-[#1B2440] text-xs font-medium text-[#F4F5FF] disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-400 text-xs font-semibold text-[#080B16] disabled:opacity-60"
              >
                {deleting ? 'Deleting...' : 'Delete Record'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk CSV Import Modal */}
      {importOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs overflow-y-auto">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="import-modal-title"
            className="w-full max-w-2xl p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.12)] shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 id="import-modal-title" className="font-display text-lg font-semibold text-[#F4F5FF]">
                  Bulk CSV Dataset Import
                </h2>
                <p className="text-xs text-[#A0A8C0] mt-0.5">
                  Validates headers, dates, times, duplicates, and intervals row by row in Python.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                aria-label="Close bulk import dialog"
                className="p-2 rounded-lg text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#1B2440]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-xs font-medium text-[#F4F5FF] cursor-pointer">
                <Upload className="w-3.5 h-3.5 text-[#54D9C6]" />
                <span>Choose .csv File</span>
                <input type="file" accept=".csv,text/csv" onChange={handleFileUpload} className="sr-only" />
              </label>

              <button
                type="button"
                onClick={() => {
                  setCsvText(SAMPLE_TEST_CSV);
                  setSelectedFileName('sample_mixed_test.csv');
                  setImportResult(null);
                  setImportError(null);
                }}
                className="px-3.5 py-2 rounded-lg bg-[#101629] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] text-xs font-medium text-[#C5A8FF]"
              >
                Load Mixed Valid &amp; Malformed Sample CSV
              </button>

              {selectedFileName && (
                <span className="text-xs font-mono text-[#A0A8C0]">
                  Selected: {selectedFileName}
                </span>
              )}
            </div>

            <textarea
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="sleep_date,bedtime,wake_date,wake_time,notes"
              aria-label="CSV content to import"
              className="w-full p-3 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] font-mono text-xs text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
            />

            {importError && (
              <div className="p-3 rounded-lg bg-[#101629] border border-red-400/40 flex items-center gap-2 text-xs text-red-300">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{importError}</span>
              </div>
            )}

            {importResult && (
              <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.08)] space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 rounded-md bg-[#151D34]">
                    <p className="text-[#A0A8C0]">Total Rows</p>
                    <p className="font-mono font-semibold text-[#F4F5FF] mt-0.5">
                      {importResult.total_rows}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-md bg-[#151D34]">
                    <p className="text-[#A0A8C0]">Imported</p>
                    <p className="inline-flex items-center gap-1 font-mono font-semibold text-[#54D9C6] mt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {importResult.imported_count}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-md bg-[#151D34]">
                    <p className="text-[#A0A8C0]">Invalid Rows</p>
                    <p className="font-mono font-semibold text-red-400 mt-0.5">
                      {importResult.invalid_count ?? importResult.rejected_count}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-md bg-[#151D34]">
                    <p className="text-[#A0A8C0]">Duplicates</p>
                    <p className="font-mono font-semibold text-amber-400 mt-0.5">
                      {importResult.duplicate_count ?? 0}
                    </p>
                  </div>
                </div>

                {importResult.error_logs.length > 0 && (
                  <div className="max-h-40 overflow-y-auto border-t border-[rgba(255,255,255,0.08)] pt-2.5 space-y-1.5">
                    <p className="text-xs font-semibold text-[#F4F5FF]">Row-by-Row Validation Log</p>
                    {importResult.error_logs.map((errItem) => (
                      <div
                        key={errItem.row}
                        className={`text-xs font-mono ${
                          errItem.category === 'duplicate' ? 'text-amber-300' : 'text-red-300'
                        }`}
                      >
                        Row {errItem.row} [{errItem.category ?? 'rejected'}]: {errItem.error}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setImportOpen(false)}
                className="px-4 py-2 rounded-lg bg-[#1B2440] text-xs font-medium text-[#F4F5FF]"
              >
                Close
              </button>
              <button
                type="button"
                disabled={importing}
                onClick={handleRunImport}
                className="px-4 py-2 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] disabled:opacity-60 text-xs font-semibold text-[#080B16]"
              >
                {importing ? 'Validating & Importing...' : 'Run Bulk Import'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
