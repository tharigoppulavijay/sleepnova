import React, { useCallback, useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Edit3, PlusCircle, Trash2 } from 'lucide-react';
import { ApiError, formatMinutes, sleepApi } from '../api/client';
import type { SleepRecord } from '../types/sleep';

interface LoggerPageProps {
  initialEditRecord?: SleepRecord | null;
  onClearEdit?: () => void;
}

function getDefaultDates() {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const toIso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return { sleepDate: toIso(yesterday), wakeDate: toIso(today) };
}

export const LoggerPage: React.FC<LoggerPageProps> = ({ initialEditRecord, onClearEdit }) => {
  const defaults = getDefaultDates();
  const [editingId, setEditingId] = useState<string | null>(initialEditRecord?.id || null);
  const [sleepDate, setSleepDate] = useState(initialEditRecord?.sleep_date || defaults.sleepDate);
  const [bedtime, setBedtime] = useState(initialEditRecord?.bedtime || '22:30');
  const [wakeDate, setWakeDate] = useState(initialEditRecord?.wake_date || defaults.wakeDate);
  const [wakeTime, setWakeTime] = useState(initialEditRecord?.wake_time || '06:30');
  const [notes, setNotes] = useState(initialEditRecord?.notes || '');

  const [previewText, setPreviewText] = useState<string>('8h 00m (8.0 hrs)');
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [crossesMidnight, setCrossesMidnight] = useState<boolean>(true);

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [recent, setRecent] = useState<SleepRecord[]>([]);

  const loadRecent = useCallback(async () => {
    try {
      const res = await sleepApi.listRecords({ page: 1, page_size: 8, sort: 'newest' });
      setRecent(res.records);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    loadRecent();
  }, [loadRecent]);

  useEffect(() => {
    if (initialEditRecord) {
      setEditingId(initialEditRecord.id);
      setSleepDate(initialEditRecord.sleep_date);
      setBedtime(initialEditRecord.bedtime);
      setWakeDate(initialEditRecord.wake_date);
      setWakeTime(initialEditRecord.wake_time);
      setNotes(initialEditRecord.notes);
    }
  }, [initialEditRecord]);

  // Live Python backend duration preview whenever inputs change
  useEffect(() => {
    if (!sleepDate || !bedtime || !wakeDate || !wakeTime) {
      setPreviewText('—');
      setPreviewError('Enter sleep start and wake-up date/time values.');
      return;
    }
    const timer = window.setTimeout(async () => {
      try {
        const res = await sleepApi.previewDuration({
          sleep_date: sleepDate,
          bedtime,
          wake_date: wakeDate,
          wake_time: wakeTime,
        });
        setPreviewText(`${res.formatted} (${res.duration_hours} hrs)`);
        setCrossesMidnight(res.crosses_midnight);
        setPreviewError(null);
      } catch (err) {
        setPreviewText('Invalid range');
        setPreviewError(err instanceof Error ? err.message : 'Invalid time combination.');
      }
    }, 150);

    return () => window.clearTimeout(timer);
  }, [sleepDate, bedtime, wakeDate, wakeTime]);

  const resetForm = () => {
    const d = getDefaultDates();
    setEditingId(null);
    setSleepDate(d.sleepDate);
    setBedtime('22:30');
    setWakeDate(d.wakeDate);
    setWakeTime('06:30');
    setNotes('');
    setFieldErrors({});
    setSubmitError(null);
    onClearEdit?.();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFieldErrors({});
    setSubmitError(null);
    setSubmitSuccess(null);

    try {
      if (editingId) {
        const res = await sleepApi.updateRecord(editingId, {
          sleep_date: sleepDate,
          bedtime,
          wake_date: wakeDate,
          wake_time: wakeTime,
          notes,
        });
        setSubmitSuccess(
          `Updated ${res.record.id} · Duration ${formatMinutes(res.record.duration_minutes)} persisted to JSON & CSV.`,
        );
        resetForm();
      } else {
        const res = await sleepApi.createRecord({
          sleep_date: sleepDate,
          bedtime,
          wake_date: wakeDate,
          wake_time: wakeTime,
          notes,
        });
        setSubmitSuccess(
          `Saved ${res.record.id} · Duration ${formatMinutes(res.record.duration_minutes)} persisted to JSON & CSV.`,
        );
        setNotes('');
      }
      await loadRecent();
    } catch (err) {
      if (err instanceof ApiError) {
        setSubmitError(err.message);
        setFieldErrors(err.fieldErrors);
      } else {
        setSubmitError(err instanceof Error ? err.message : 'Failed to save sleep record.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditClick = (rec: SleepRecord) => {
    setEditingId(rec.id);
    setSleepDate(rec.sleep_date);
    setBedtime(rec.bedtime);
    setWakeDate(rec.wake_date);
    setWakeTime(rec.wake_time);
    setNotes(rec.notes);
    setSubmitError(null);
    setSubmitSuccess(null);
    setFieldErrors({});
  };

  const handleDeleteClick = async (id: string) => {
    if (deletingId) return;
    setDeletingId(id);
    try {
      await sleepApi.deleteRecord(id);
      if (editingId === id) resetForm();
      setSubmitSuccess(`Deleted record ${id}.`);
      await loadRecent();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Delete failed.');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
          {editingId ? `Edit Sleep Record · ${editingId}` : 'Sleep Logger'}
        </h1>
        <p className="text-sm text-[#A0A8C0] mt-1">
          Record sleep and wake-up timestamps with real-time Python duration calculation and strict
          server-side validation.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form Card */}
        <form
          onSubmit={handleSubmit}
          noValidate
          className="lg:col-span-7 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-5"
        >
          {submitSuccess && (
            <div
              role="status"
              className="p-3.5 rounded-lg bg-[#101629] border border-[#54D9C6]/40 flex items-start gap-2.5 text-xs text-[#54D9C6]"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{submitSuccess}</span>
            </div>
          )}

          {submitError && (
            <div
              role="alert"
              className="p-3.5 rounded-lg bg-[#101629] border border-red-400/40 flex items-start gap-2.5 text-xs text-red-300"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
              <span>{submitError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="sleep-date" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
                Sleep Start Date
              </label>
              <input
                id="sleep-date"
                type="date"
                value={sleepDate}
                onChange={(e) => setSleepDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
                required
              />
              {fieldErrors.sleep_date && (
                <p className="mt-1 text-xs text-red-400">{fieldErrors.sleep_date}</p>
              )}
            </div>

            <div>
              <label htmlFor="bedtime" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
                Bedtime (24h HH:MM)
              </label>
              <input
                id="bedtime"
                type="time"
                value={bedtime}
                onChange={(e) => setBedtime(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
                required
              />
              {fieldErrors.bedtime && (
                <p className="mt-1 text-xs text-red-400">{fieldErrors.bedtime}</p>
              )}
            </div>

            <div>
              <label htmlFor="wake-date" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
                Wake-up Date
              </label>
              <input
                id="wake-date"
                type="date"
                value={wakeDate}
                onChange={(e) => setWakeDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
                required
              />
              {fieldErrors.wake_date && (
                <p className="mt-1 text-xs text-red-400">{fieldErrors.wake_date}</p>
              )}
            </div>

            <div>
              <label htmlFor="wake-time" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
                Wake-up Time (24h HH:MM)
              </label>
              <input
                id="wake-time"
                type="time"
                value={wakeTime}
                onChange={(e) => setWakeTime(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF] focus:border-[#9585FF] focus:outline-none"
                required
              />
              {fieldErrors.wake_time && (
                <p className="mt-1 text-xs text-red-400">{fieldErrors.wake_time}</p>
              )}
            </div>
          </div>

          {/* Calculated Duration Preview Box */}
          <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.08)] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <p className="text-xs text-[#A0A8C0]">Calculated Sleep Duration (Python Engine)</p>
              <p
                className={`font-mono text-xl font-semibold tabular-nums mt-0.5 ${
                  previewError ? 'text-amber-400' : 'text-[#54D9C6]'
                }`}
              >
                {previewText}
              </p>
              {previewError && <p className="text-xs text-amber-300 mt-1">{previewError}</p>}
            </div>
            {!previewError && (
              <span className="text-xs font-mono text-[#C5A8FF]">
                {crossesMidnight ? 'Overnight session' : 'Same-day session'}
              </span>
            )}
          </div>

          <div>
            <label htmlFor="sleep-notes" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Optional Notes ({notes.length}/500)
            </label>
            <textarea
              id="sleep-notes"
              rows={3}
              maxLength={500}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Quiet evening, consistent wind-down routine"
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm text-[#F4F5FF] placeholder:text-[#A0A8C0]/45 focus:border-[#9585FF] focus:outline-none"
            />
            {fieldErrors.notes && (
              <p className="mt-1 text-xs text-red-400">{fieldErrors.notes}</p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] disabled:opacity-60 text-[#080B16] text-sm font-semibold transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{submitting ? 'Saving...' : editingId ? 'Update Record' : 'Save Sleep Record'}</span>
            </button>

            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2.5 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-sm font-medium text-[#F4F5FF] transition-colors"
              >
                Cancel Edit
              </button>
            )}
          </div>
        </form>

        {/* Quick Validation Helper + Recent Entries */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <h2 className="font-display text-sm font-semibold text-[#F4F5FF] mb-2">
              Validation Rules Enforced
            </h2>
            <ul className="space-y-1.5 text-xs text-[#A0A8C0]">
              <li>· Exact datetime difference across midnight transitions</li>
              <li>· Rejects zero, negative, or &gt;24h single sessions</li>
              <li>· Blocks duplicate or overlapping time intervals</li>
              <li>· Preserves user-entered values without silent mutation</li>
            </ul>
          </div>

          <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <h2 className="font-display text-sm font-semibold text-[#F4F5FF] mb-3">
              Recent Entries (Quick Edit / Delete)
            </h2>
            {recent.length === 0 ? (
              <p className="text-xs text-[#A0A8C0]">No entries logged yet.</p>
            ) : (
              <div className="divide-y divide-[rgba(255,255,255,0.06)]">
                {recent.map((rec) => (
                  <div key={rec.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-mono text-xs tabular-nums text-[#F4F5FF]">
                        {rec.sleep_date} · {rec.bedtime} -&gt; {rec.wake_time}
                      </p>
                      <p className="text-xs text-[#54D9C6] font-mono tabular-nums mt-0.5">
                        {formatMinutes(rec.duration_minutes)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleEditClick(rec)}
                        aria-label={`Edit record ${rec.id}`}
                        className="p-1.5 rounded-md text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#1B2440]"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={deletingId === rec.id}
                        onClick={() => handleDeleteClick(rec.id)}
                        aria-label={`Delete record ${rec.id}`}
                        className="p-1.5 rounded-md text-[#A0A8C0] hover:text-red-400 hover:bg-[#1B2440] disabled:opacity-40"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
