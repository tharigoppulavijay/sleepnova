import React, { useEffect, useState } from 'react';
import { sleepApi } from '../api/client';

export const AboutPage: React.FC = () => {
  const [health, setHealth] = useState<{ engine: string; version: string; record_count: number } | null>(null);

  useEffect(() => {
    sleepApi
      .health()
      .then((res) => setHealth(res))
      .catch(() => {});
  }, []);

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <p className="text-xs font-mono text-[#54D9C6] mb-1">
          StudentLife Hack · Project #32 · Health &amp; Wellbeing
        </p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
          About SleepNova
        </h1>
        <p className="text-sm text-[#A0A8C0] mt-1.5 leading-relaxed">
          SleepNova is a local-first Sleep Routine Analyzer combining a modular Python 3.11
          analytical backend, dual CSV/JSON persistence, an interactive terminal CLI, and a modern
          web dashboard.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-3">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            Architecture &amp; Runtime Transparency
          </h2>
          <p className="text-xs text-[#A0A8C0] leading-relaxed">
            Every calculation, validation check, search filter, executive summary, CSV import, and
            report export in this interface is executed directly by the Python modules inside{' '}
            <span className="font-mono text-[#F4F5FF]">backend/</span>.
          </p>
          {health && (
            <div className="pt-2 border-t border-[rgba(255,255,255,0.06)] text-xs font-mono text-[#C5A8FF] space-y-1">
              <div>Active Engine: Python {health.version}</div>
              <div>Persisted Records: {health.record_count}</div>
            </div>
          )}
        </div>

        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-3">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            Persistence &amp; Recovery Strategy
          </h2>
          <p className="text-xs text-[#A0A8C0] leading-relaxed">
            <span className="font-mono text-[#F4F5FF]">data/sleep_records.json</span> acts as the
            primary canonical store, while{' '}
            <span className="font-mono text-[#F4F5FF]">data/sleep_records.csv</span> is atomically
            synchronized on every write. If JSON is damaged or missing, the damaged file is backed up
            and records are recovered from the CSV mirror.
          </p>
        </div>
      </div>

      <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-4">
        <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
          Local Python Execution Commands
        </h2>
        <div className="space-y-3 font-mono text-xs bg-[#080B16] p-4 rounded-lg border border-[rgba(255,255,255,0.08)] text-[#A0A8C0] overflow-x-auto">
          <div>
            <span className="text-[#54D9C6]"># 1. Install standalone Flask + Matplotlib dependencies</span>
            <div className="text-[#F4F5FF]">pip install -r requirements.txt</div>
          </div>
          <div>
            <span className="text-[#54D9C6]"># 2. Launch the Interactive Terminal Interface (CLI)</span>
            <div className="text-[#F4F5FF]">python3 cli.py</div>
          </div>
          <div>
            <span className="text-[#54D9C6]"># 3. Launch the Standalone Flask Web Application</span>
            <div className="text-[#F4F5FF]">python3 app.py</div>
          </div>
          <div>
            <span className="text-[#54D9C6]"># 4. Execute the Automated Python Test Suite</span>
            <div className="text-[#F4F5FF]">python3 -m unittest discover -s tests -v</div>
          </div>
        </div>
      </div>

      <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-2">
        <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
          Methodology &amp; Non-Diagnostic Scope
        </h2>
        <p className="text-xs text-[#A0A8C0] leading-relaxed">
          Sleep duration is calculated from full start and wake date-time pairs to support midnight
          crossings accurately. Consistency metrics use midnight-centered standard deviation of
          bedtimes and wake times. All indicators and threshold warnings are informational routine
          summaries and are never intended as medical diagnosis.
        </p>
      </div>
    </div>
  );
};
