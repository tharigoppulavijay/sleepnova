import React, { useEffect, useState } from 'react';
import { ArrowRight, BarChart3, CheckCircle2, FileText, ShieldCheck, Terminal } from 'lucide-react';
import { sleepApi } from '../api/client';
import { BrandMark } from '../components/BrandMark';
import type { AppRoute, ExecutiveSummary } from '../types/sleep';

interface LandingPageProps {
  onNavigate: (route: AppRoute) => void;
}

const HERO_IMAGE = '/src/assets/images/sleepnova_hero_horizon_1795499703161.jpg';
const WAVE_IMAGE = '/src/assets/images/sleepnova_circadian_wave_1795499703073.jpg';

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const [summary, setSummary] = useState<ExecutiveSummary | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [waveImgFailed, setWaveImgFailed] = useState(false);

  useEffect(() => {
    let active = true;
    sleepApi
      .getSummary()
      .then((data) => {
        if (active) setSummary(data);
      })
      .catch(() => {
        // Non-blocking on landing preview
      });
    return () => {
      active = false;
    };
  }, []);

  const overall = summary?.overall.stats;
  const consistency = summary?.overall.consistency;

  return (
    <div className="min-h-screen bg-[#080B16] text-[#F4F5FF]">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 border-b border-[rgba(255,255,255,0.08)] bg-[#080B16]/90 backdrop-blur-md">
        <div className="max-w-[1200px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/');
            }}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0"
          >
            <BrandMark className="w-7 h-7" />
            <span className="font-display text-lg font-bold tracking-tight text-[#F4F5FF]">
              SleepNova
            </span>
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#A0A8C0]" aria-label="Landing navigation">
            <a href="#features" className="hover:text-[#F4F5FF] transition-colors whitespace-nowrap shrink-0">
              Features
            </a>
            <a href="#analytics-preview" className="hover:text-[#F4F5FF] transition-colors whitespace-nowrap shrink-0">
              Analytics
            </a>
            <a href="#how-it-works" className="hover:text-[#F4F5FF] transition-colors whitespace-nowrap shrink-0">
              How It Works
            </a>
            <a href="#project-info" className="hover:text-[#F4F5FF] transition-colors whitespace-nowrap shrink-0">
              Project Info
            </a>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('/dashboard')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] text-[#080B16] text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              <span>Explore Dashboard</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-[1200px] mx-auto px-6 pt-12 pb-16 lg:pt-16 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-medium tracking-wide text-[#54D9C6] mb-4">
              SleepNova · Project #32 · Health &amp; Wellbeing
            </p>
            <h1 className="font-display text-[clamp(2.25rem,4vw,3.75rem)] font-bold leading-[1.08] tracking-tight text-[#F4F5FF] text-balance mb-5">
              Every Night Tells a Story.
            </h1>
            <p className="text-base sm:text-lg text-[#A0A8C0] leading-relaxed max-w-[54ch] mb-8">
              Understand your sleep patterns, track your daily routine and discover meaningful insights
              with SleepNova. Powered by a Python analytical engine with dual CSV and JSON persistence.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate('/dashboard')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] text-[#080B16] text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <span>Explore Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href="#features"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.12)] text-[#F4F5FF] text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              >
                <span>Discover Features</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[280px] sm:min-h-[340px] rounded-xl overflow-hidden border border-[rgba(255,255,255,0.08)] bg-[#101629]">
              {!heroImgFailed ? (
                <img
                  src={HERO_IMAGE}
                  alt="Calm nocturnal architectural horizon representing SleepNova rest tracking"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-linear-to-br from-[#101629] via-[#151D34] to-[#080B16]">
                  <BrandMark className="w-12 h-12 mb-3" />
                  <p className="text-sm text-[#A0A8C0]">SleepNova Nocturnal Sanctuary</p>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#080B16]/85 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-center justify-between gap-4 text-xs text-[#F4F5FF]">
                <span className="font-mono tabular-nums text-[#C5A8FF]">
                  Your Sleep. Your Patterns. Your Insights.
                </span>
                <span className="text-[#A0A8C0]">Local-First · Python 3.11 Core</span>
              </div>
            </div>
          </div>
        </div>

        {/* Live KPI Strip anchored directly beneath hero split */}
        <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-4 border-t border-[rgba(255,255,255,0.08)] pt-8">
          <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <p className="text-xs text-[#A0A8C0] mb-1">Stored Sleep Sessions</p>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F5FF]">
              {overall ? overall.record_count : '39'}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <p className="text-xs text-[#A0A8C0] mb-1">Average Duration</p>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#54D9C6]">
              {overall ? overall.average_formatted : '7h 50m'}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <p className="text-xs text-[#A0A8C0] mb-1">Schedule Consistency</p>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#9585FF]">
              {consistency?.sufficient_data ? `${consistency.consistency_score}%` : '—'}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
            <p className="text-xs text-[#A0A8C0] mb-1">Export Formats</p>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#C5A8FF]">
              5 Formats
            </p>
          </div>
        </div>
      </section>

      {/* Feature Showcase (Asymmetric Bento Grid) */}
      <section id="features" className="border-t border-[rgba(255,255,255,0.08)] bg-[#101629]/50 py-16 lg:py-24">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-medium text-[#54D9C6] mb-2">Core Capabilities</p>
            <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-[#F4F5FF] text-balance">
              Built for accurate duration math, reliable storage, and clear routine analysis.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 p-7 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-4 mb-4">
                  <span className="font-display text-lg font-semibold text-[#F4F5FF]">
                    01. Midnight-Aware Sleep Calculation &amp; Defensive Validation
                  </span>
                  <ShieldCheck className="w-5 h-5 text-[#54D9C6] shrink-0" />
                </div>
                <p className="text-sm sm:text-base text-[#A0A8C0] leading-relaxed max-w-[62ch]">
                  Computes exact elapsed minutes using complete sleep start and wake-up date-time
                  values in Python. Detects overlapping intervals, duplicate records, future dates,
                  and negative durations without ever silently modifying user inputs.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[rgba(255,255,255,0.08)] flex flex-wrap items-center gap-3 text-xs font-mono text-[#C5A8FF]">
                <span>22:30 -&gt; 06:30 = 8h 00m</span>
                <span aria-hidden="true">·</span>
                <span>Overlap Guard</span>
                <span aria-hidden="true">·</span>
                <span>Strict Backend Checks</span>
              </div>
            </div>

            <div className="p-7 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <div className="flex items-center justify-between gap-4 mb-4">
                <span className="font-display text-lg font-semibold text-[#F4F5FF]">
                  02. Dual CSV &amp; JSON Persistence
                </span>
                <CheckCircle2 className="w-5 h-5 text-[#9585FF] shrink-0" />
              </div>
              <p className="text-sm text-[#A0A8C0] leading-relaxed">
                Atomic temporary-file writes keep JSON and CSV synchronized after every mutation.
                Corrupted JSON files are preserved automatically and recovered from the CSV mirror.
              </p>
            </div>

            <div className="p-7 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <div className="flex items-center justify-between gap-4 mb-4">
                <span className="font-display text-lg font-semibold text-[#F4F5FF]">
                  03. Multi-Format Report Center
                </span>
                <FileText className="w-5 h-5 text-[#54D9C6] shrink-0" />
              </div>
              <p className="text-sm text-[#A0A8C0] leading-relaxed">
                Generate daily, weekly, monthly, and complete historical summaries exported as CSV,
                JSON, Markdown, plain-text audit logs, and Matplotlib PNG trend charts.
              </p>
            </div>

            <div className="md:col-span-2 p-7 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-4 mb-4">
                  <span className="font-display text-lg font-semibold text-[#F4F5FF]">
                    04. Unified Web Dashboard &amp; Interactive Terminal CLI
                  </span>
                  <Terminal className="w-5 h-5 text-[#9585FF] shrink-0" />
                </div>
                <p className="text-sm sm:text-base text-[#A0A8C0] leading-relaxed max-w-[62ch]">
                  Both the browser workspace and the menu-driven terminal CLI execute the exact same
                  Python modules in <span className="font-mono text-[#F4F5FF]">backend/</span>,
                  including bulk CSV import with row-by-row validation logs and threshold alerts.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[rgba(255,255,255,0.08)] flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('/logger')}
                  className="text-xs font-semibold text-[#9585FF] hover:text-[#C5A8FF] transition-colors"
                >
                  Open Sleep Logger -&gt;
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('/history')}
                  className="text-xs font-semibold text-[#54D9C6] hover:text-[#F4F5FF] transition-colors"
                >
                  Try Bulk CSV Import -&gt;
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Analytics Preview */}
      <section id="analytics-preview" className="py-16 lg:py-24 max-w-[1200px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-5">
            <div className="h-full min-h-[260px] rounded-xl overflow-hidden border border-[rgba(255,255,255,0.08)] bg-[#101629]">
              {!waveImgFailed ? (
                <img
                  src={WAVE_IMAGE}
                  alt="Isometric nocturnal circadian wave ribbons illustrating SleepNova pattern analysis"
                  referrerPolicy="no-referrer"
                  onError={() => setWaveImgFailed(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-8">
                  <BarChart3 className="w-10 h-10 text-[#9585FF]" />
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs font-medium text-[#54D9C6] mb-2">Analytics Engine</p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF] text-balance mb-4">
              Circular bedtime math and honest period comparisons.
            </h2>
            <p className="text-sm sm:text-base text-[#A0A8C0] leading-relaxed mb-6">
              Traditional averages fail across midnight—averaging 23:30 and 00:30 naively produces
              12:00 noon. SleepNova centers bedtime offsets around midnight in Python so your
              schedule regularity and trend lines remain mathematically sound.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-7">
              <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
                <p className="text-xs text-[#A0A8C0] mb-1">7-Day Average</p>
                <p className="font-mono text-lg font-semibold tabular-nums text-[#F4F5FF]">
                  {summary ? summary.weekly.stats.average_formatted : '7h 55m'}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
                <p className="text-xs text-[#A0A8C0] mb-1">30-Day Average</p>
                <p className="font-mono text-lg font-semibold tabular-nums text-[#F4F5FF]">
                  {summary ? summary.monthly.stats.average_formatted : '7h 48m'}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
                <p className="text-xs text-[#A0A8C0] mb-1">Goal Attainment</p>
                <p className="font-mono text-lg font-semibold tabular-nums text-[#54D9C6]">
                  {overall ? `${overall.goal_achievement_pct}%` : '—'}
                </p>
              </div>
            </div>
            <div>
              <button
                type="button"
                onClick={() => onNavigate('/analytics')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-sm font-medium text-[#F4F5FF] transition-colors"
              >
                <span>Explore Full Analytics</span>
                <ArrowRight className="w-4 h-4 text-[#9585FF]" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="border-t border-[rgba(255,255,255,0.08)] bg-[#101629]/40 py-16">
        <div className="max-w-[1200px] mx-auto px-6">
          <p className="text-xs font-medium text-[#54D9C6] mb-2">Workflow</p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF] mb-10">
            How SleepNova processes every record
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="font-mono text-xs text-[#9585FF] mb-2">Step 01</p>
              <h3 className="font-display text-lg font-semibold text-[#F4F5FF] mb-2">
                Log &amp; Preview Duration
              </h3>
              <p className="text-sm text-[#A0A8C0] leading-relaxed">
                Enter sleep start date, bedtime, wake-up date, wake-up time, and optional notes via
                the web logger, bulk CSV uploader, or interactive terminal CLI.
              </p>
            </div>
            <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="font-mono text-xs text-[#9585FF] mb-2">Step 02</p>
              <h3 className="font-display text-lg font-semibold text-[#F4F5FF] mb-2">
                Validate &amp; Sync Storage
              </h3>
              <p className="text-sm text-[#A0A8C0] leading-relaxed">
                Python validates bounds, prevents duplicate or overlapping sessions, and atomically
                writes synchronized records to local JSON and CSV files.
              </p>
            </div>
            <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
              <p className="font-mono text-xs text-[#9585FF] mb-2">Step 03</p>
              <h3 className="font-display text-lg font-semibold text-[#F4F5FF] mb-2">
                Analyze &amp; Export Reports
              </h3>
              <p className="text-sm text-[#A0A8C0] leading-relaxed">
                Review weekly/monthly charts, threshold indicators, consistency metrics, and export
                executive summaries in CSV, JSON, Markdown, TXT, or PNG.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Project Information & Quiet Footer */}
      <footer id="project-info" className="border-t border-[rgba(255,255,255,0.08)] py-12">
        <div className="max-w-[1200px] mx-auto px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <BrandMark className="w-5 h-5" />
              <span className="font-display font-semibold text-[#F4F5FF]">SleepNova</span>
            </div>
            <p className="text-xs text-[#A0A8C0]">
              StudentLife Hack · Project #32: Sleep Routine Analyzer · Health &amp; Wellbeing
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#A0A8C0]">
            <button type="button" onClick={() => onNavigate('/dashboard')} className="hover:text-[#F4F5FF] transition-colors">
              Dashboard
            </button>
            <button type="button" onClick={() => onNavigate('/logger')} className="hover:text-[#F4F5FF] transition-colors">
              Sleep Logger
            </button>
            <button type="button" onClick={() => onNavigate('/reports')} className="hover:text-[#F4F5FF] transition-colors">
              Report Center
            </button>
            <button type="button" onClick={() => onNavigate('/about')} className="hover:text-[#F4F5FF] transition-colors">
              About &amp; Architecture
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
