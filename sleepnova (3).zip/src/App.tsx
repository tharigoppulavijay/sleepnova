import React, { useCallback, useEffect, useState } from 'react';
import { AppShell } from './components/AppShell';
import { AboutPage } from './pages/AboutPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { DashboardPage } from './pages/DashboardPage';
import { HistoryPage } from './pages/HistoryPage';
import { LandingPage } from './pages/LandingPage';
import { LoggerPage } from './pages/LoggerPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import type { AppRoute, SleepRecord } from './types/sleep';

const VALID_ROUTES: AppRoute[] = [
  '/',
  '/dashboard',
  '/logger',
  '/history',
  '/analytics',
  '/reports',
  '/settings',
  '/about',
];

function resolveRoute(pathname: string): AppRoute {
  const normalized = pathname === '' ? '/' : pathname;
  return VALID_ROUTES.includes(normalized as AppRoute) ? (normalized as AppRoute) : '/';
}

const ROUTE_TITLES: Record<AppRoute, string> = {
  '/': 'Landing',
  '/dashboard': 'Overview',
  '/logger': 'Sleep Logger',
  '/history': 'Sleep History',
  '/analytics': 'Analytics',
  '/reports': 'Report Center',
  '/settings': 'Settings',
  '/about': 'About SleepNova',
};

export function App() {
  const [route, setRoute] = useState<AppRoute>(() => resolveRoute(window.location.pathname));
  const [editRecord, setEditRecord] = useState<SleepRecord | null>(null);

  useEffect(() => {
    const onPopState = () => {
      setRoute(resolveRoute(window.location.pathname));
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = useCallback((nextRoute: AppRoute) => {
    if (window.location.pathname !== nextRoute) {
      window.history.pushState({}, '', nextRoute);
    }
    setRoute(nextRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleEditRecord = useCallback(
    (rec: SleepRecord) => {
      setEditRecord(rec);
      navigate('/logger');
    },
    [navigate],
  );

  if (route === '/') {
    return <LandingPage onNavigate={navigate} />;
  }

  return (
    <AppShell currentRoute={route} onNavigate={navigate} breadcrumbTitle={ROUTE_TITLES[route]}>
      {route === '/dashboard' && <DashboardPage onNavigate={navigate} />}
      {route === '/logger' && (
        <LoggerPage initialEditRecord={editRecord} onClearEdit={() => setEditRecord(null)} />
      )}
      {route === '/history' && <HistoryPage onEditRecord={handleEditRecord} />}
      {route === '/analytics' && <AnalyticsPage />}
      {route === '/reports' && <ReportsPage />}
      {route === '/settings' && <SettingsPage />}
      {route === '/about' && <AboutPage />}
    </AppShell>
  );
}

export default App;
