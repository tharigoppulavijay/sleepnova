import type {
  ExecutiveSummary,
  ImportCsvResult,
  MonthlyAnalytics,
  RecordsQueryResponse,
  ReportPreview,
  SleepRecord,
  SleepSettings,
  WeeklyAnalytics,
} from '../types/sleep';

export class ApiError extends Error {
  status: number;
  fieldErrors: Record<string, string>;

  constructor(message: string, status = 400, fieldErrors: Record<string, string> = {}) {
    super(message);
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function requestJson<T>(url: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set('X-Requested-With', 'SleepNova-Client');
  if (init.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(url, { ...init, headers });
  const data = await response.json().catch(() => ({ ok: false, error: 'Invalid server response.' }));

  if (!response.ok || data.ok === false) {
    throw new ApiError(
      data.error || `Request failed (${response.status})`,
      response.status,
      data.field_errors || {},
    );
  }
  return data as T;
}

export const sleepApi = {
  health: () => requestJson<{ ok: boolean; engine: string; version: string; record_count: number }>('/api/health'),

  listRecords: (params: {
    keyword?: string;
    date?: string;
    start_date?: string;
    end_date?: string;
    min_hours?: string;
    max_hours?: string;
    sort?: string;
    page?: number;
    page_size?: number;
  } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && String(v) !== '') {
        qs.set(k, String(v));
      }
    });
    return requestJson<RecordsQueryResponse>(`/api/records?${qs.toString()}`);
  },

  previewDuration: (payload: {
    sleep_date: string;
    bedtime: string;
    wake_date: string;
    wake_time: string;
  }) =>
    requestJson<{
      ok: boolean;
      duration_minutes: number;
      duration_hours: number;
      formatted: string;
      crosses_midnight: boolean;
    }>('/api/records/preview', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  createRecord: (payload: {
    sleep_date: string;
    bedtime: string;
    wake_date: string;
    wake_time: string;
    notes: string;
  }) =>
    requestJson<{ ok: boolean; record: SleepRecord }>('/api/records', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateRecord: (
    id: string,
    payload: {
      sleep_date: string;
      bedtime: string;
      wake_date: string;
      wake_time: string;
      notes: string;
    },
  ) =>
    requestJson<{ ok: boolean; record: SleepRecord }>(`/api/records/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  deleteRecord: (id: string) =>
    requestJson<{ ok: boolean; deleted: SleepRecord }>(`/api/records/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  getSummary: () => requestJson<ExecutiveSummary & { ok: boolean }>('/api/analytics/summary'),
  getWeekly: () => requestJson<WeeklyAnalytics & { ok: boolean }>('/api/analytics/weekly'),
  getMonthly: () => requestJson<MonthlyAnalytics & { ok: boolean }>('/api/analytics/monthly'),

  getSettings: () => requestJson<{ ok: boolean; settings: SleepSettings }>('/api/settings'),
  saveSettings: (settings: SleepSettings) =>
    requestJson<{ ok: boolean; settings: SleepSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  importCsv: (csvContent: string) =>
    requestJson<ImportCsvResult>('/api/import/csv', {
      method: 'POST',
      body: JSON.stringify({ csv_content: csvContent }),
    }),

  resetDemo: () =>
    requestJson<{ ok: boolean; record_count: number }>('/api/demo/reset', {
      method: 'POST',
    }),

  clearRecords: () =>
    requestJson<{ ok: boolean; removed_count: number }>('/api/records/clear', {
      method: 'POST',
    }),

  getReportPreview: (period: string) =>
    requestJson<ReportPreview>(`/api/reports/preview?period=${encodeURIComponent(period)}`),
};

export function formatMinutes(minutes: number): string {
  const safe = Math.max(0, Math.round(minutes));
  const h = Math.floor(safe / 60);
  const m = safe % 60;
  return `${h}h ${String(m).padStart(2, '0')}m`;
}

export function formatDisplayDate(
  isoDate: string,
  format: SleepSettings['preferred_date_format'] = 'YYYY-MM-DD',
): string {
  if (!isoDate || !/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return isoDate;
  const [y, m, d] = isoDate.split('-');
  if (format === 'MM/DD/YYYY') return `${m}/${d}/${y}`;
  if (format === 'DD/MM/YYYY') return `${d}/${m}/${y}`;
  if (format === 'MMM DD, YYYY') {
    const dt = new Date(`${isoDate}T00:00:00`);
    return dt.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
  }
  return isoDate;
}
