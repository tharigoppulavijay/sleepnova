# SleepNova — Smart Sleep Routine Analyzer

**Project #32: Sleep Routine Analyzer | Category: Health & Wellbeing | StudentLife Hack**

> *Your Sleep. Your Patterns. Your Insights.*

SleepNova is a local-first Sleep Routine Analyzer powered by a modular Python 3.11+ engine, dual CSV and JSON persistence, an interactive terminal CLI (`cli.py`), a standalone Flask web server (`app.py`), an optional Tkinter desktop companion (`gui.py`), and a modern dark-mode React + Chart.js web dashboard bridged directly to the Python backend.

---

## 1. Problem Statement & Objectives

Many existing sleep utilities either bury users under opaque hardware telemetry or assume every sleep session starts and ends on the same calendar date. SleepNova focuses on what students and everyday users actually need from a clean software analyzer:

- Accurate **midnight-aware sleep duration calculation** using complete `(sleep_date, bedtime)` and `(wake_date, wake_time)` timestamps.
- Strict **validation and corruption-safe storage** that refuses silent data mutation, invalid dates, or overlapping duplicates.
- Honest **trend, goal-completion, and consistency analytics** without fabricating values for unlogged days.
- Non-diagnostic **threshold indicators and informational insights** alongside portable exports (`CSV`, `JSON`, `Markdown`, `TXT`, `PNG`).

---

## 2. Core Features

1. **Midnight-Aware Duration Calculator (`backend/sleep_logic.py`)**: Exact `datetime` subtraction across overnight transitions, supporting both 24-hour (`22:45`) and 12-hour (`10:45 PM`) clock inputs.
2. **Defensive Input Validation (`backend/validation.py`)**: Rejects empty/malformed dates (`YYYY-MM-DD`), invalid times, negative/zero durations, sessions exceeding 24h (`1440` min), excessive future dates, overly long notes (`>500` chars), CSV formula injection, and duplicate/overlapping intervals.
3. **Dual CSV + JSON Persistence & Recovery (`backend/storage.py`)**:
   - Canonical store: `data/sleep_records.json`.
   - Synchronized mirror: `data/sleep_records.csv` written atomically via `tempfile` + `os.replace` + `fsync`.
   - Automatic recovery: Corrupted JSON is preserved as `sleep_records.json.corrupted.<timestamp>` and restored from CSV without crashing; `PermissionError` is handled gracefully without overwriting files.
4. **Analytics & Methodology Engine (`backend/analytics.py`)**: Daily, Weekly, Monthly, and Overall statistics, prior-week delta comparisons, circular midnight-centered bedtime consistency score, weekly goal-completion blocks, weekday vs. weekend comparisons, and transparent metric derivation formulas.
5. **Threshold Warning Indicators (`backend/warnings.py`)**: Configurable alerts for short sessions, long sessions, logging gaps, bedtime variance, and goal deviations.
6. **Charts & Multi-Format Exports (`backend/plotting.py`, `backend/reports.py`)**: Exports CSV, JSON, Markdown (`.md`), plain-text audit logs (`.txt`), and PNG charts (`weekly_trend`, `monthly_trend`, `duration_distribution`, `goal_progress`, `consistency_trend`) via Matplotlib (or pure-Python PNG fallback when Matplotlib is absent).
7. **Bulk CSV Import (`import_csv()`)**: Enforces `.csv` + 2 MB limits, validates row-by-row, separates **invalid rows** from **duplicates**, and prints an exact row-by-row rejection report.

---

## 3. Architecture Overview

```text
React + TypeScript + Chart.js UI (src/)
        │  /api/* JSON & file requests
        ▼
Express + Vite Dev/Runtime Bridge (server.ts)   ──OR──   Standalone Flask App (app.py)
        │  stdin/stdout JSON (backend/bridge.py)
        ▼
Modular Python Engine (backend/*.py + config.py)
   ├── sleep_logic.py   (datetime duration & offset math)
   ├── validation.py    (strict validation & CSV neutralization)
   ├── storage.py       (atomic JSON/CSV CRUD, search, import, recovery)
   ├── analytics.py     (Daily/Weekly/Monthly/Executive + circular consistency)
   ├── warnings.py      (configurable threshold rules)
   ├── plotting.py      (5 PNG chart generators + stdlib PNG fallback)
   └── reports.py       (CSV, JSON, Markdown, TXT, PNG exports)
        │
        ▼
Local Storage (data/sleep_records.json, data/sleep_records.csv, data/settings.json)
```

---

## 4. Tech Stack

- **Core Engine & CLI**: Python 3.11+ (`datetime`, `csv`, `json`, `statistics`, `math`, `pathlib`, `zlib`, `struct`, `unittest`)
- **Web Frontend**: React 19, TypeScript, Vite, Tailwind CSS, Chart.js (`chart.js`, `react-chartjs-2`), Lucide Icons
- **Live Bridge & Standalone Backend**: Express (`tsx server.ts` -> `python3 -m backend.bridge`), plus standalone Flask (`app.py`, `templates/`, `static/`) & Tkinter (`gui.py`)
- **Python Optional Packages**: `Flask`, `matplotlib`, `pytest` (listed in `requirements.txt`)

---

## 5. Folder Structure

```text
SleepNova/
├── app.py                   # Standalone Flask web application
├── cli.py                   # Interactive terminal CLI (14-item menu)
├── gui.py                   # Optional Tkinter desktop GUI
├── config.py                # Central paths, CSV headers, default settings
├── requirements.txt         # Python dependencies (Flask, matplotlib, pytest)
├── server.ts                # Express + Vite runtime bridging API calls to Python
├── backend/
│   ├── sleep_logic.py       # SleepRecord dataclass & datetime calculations
│   ├── validation.py        # Input validation, CSV formula escaping, overlap detection
│   ├── storage.py           # Atomic JSON/CSV persistence, recovery, search, bulk import
│   ├── analytics.py         # Daily/weekly/monthly/overall stats & circular consistency
│   ├── warnings.py          # Threshold warning engine
│   ├── plotting.py          # 5 PNG chart types (Matplotlib + stdlib fallback)
│   ├── reports.py           # CSV, JSON, Markdown, TXT, PNG report builder
│   └── bridge.py            # JSON stdin/stdout dispatcher for Express
├── data/
│   ├── sleep_records.json   # 39-record labeled demonstration dataset
│   ├── sleep_records.csv    # Synchronized CSV mirror
│   ├── settings.json        # Persistent configuration
│   └── sample_malformed_import.csv
├── templates/ & static/     # Standalone Flask HTML/CSS/JS templates
├── src/                     # React + TypeScript + Chart.js web dashboard
└── tests/                   # Automated Python unittest suite
    ├── test_sleep_logic.py
    ├── test_storage.py
    ├── test_analytics.py
    └── test_api_integration.py
```

---

## 6. Installation & Local Setup

### Option A: Zero-Dependency Python CLI & Tests
Requires only Python 3.11+:
```bash
python3 -m unittest discover -s tests -v
python3 cli.py
```

### Option B: Standalone Flask + Matplotlib (Local Workstation / VS Code)
```bash
python3 -m venv .venv
source .venv/bin/activate        # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
python3 app.py
# Open http://127.0.0.1:5000
```

### Option C: React Dashboard + Express-to-Python Full-Stack Preview (Default Live App)
```bash
npm install
npm run dev
# Open http://localhost:3000
```

> **Runtime Note**: In containerized preview environments where `flask` and `matplotlib` are not pre-installed globally, SleepNova routes live `/api/*` traffic from Express directly to Python via `backend/bridge.py` and uses the pure-Python stdlib PNG encoder fallback in `backend/plotting.py` automatically.

---

## 7. Data Storage & Sample Data

- **Primary Store (`data/sleep_records.json`)** and **Mirror (`data/sleep_records.csv`)** store identical records with `id`, `sleep_date`, `bedtime`, `wake_date`, `wake_time`, `duration_minutes`, `duration_hours`, `notes`, `is_demo`, `created_at`, and `updated_at`.
- On initial cold start with missing data files, SleepNova auto-seeds **39 realistic demonstration nights** (`is_demo: true`), clearly labeled with an informational banner in the dashboard.
- Users can log personal records (`is_demo: false`), clear all data, or restore the 39-record demonstration dataset from **Settings** or **CLI Option 14**.

---

## 8. CLI Usage (`python3 cli.py`)

Menu items available in the terminal application:
1. Add Sleep Record (interactive validation loop + overnight calculation preview)
2. View All Records (fixed-width paginated table)
3. Search Records (keyword + date filter)
4. Edit Record
5. Delete Record (with confirmation prompt)
6. Display Daily Summary
7. Display Weekly Summary (with prior-week delta)
8. Display Monthly Summary
9. Display Executive Summary (overall metrics, consistency, insights, warnings)
10. Generate Charts (PNG) — all 5 chart kinds exported to `exports/`
11. Export Reports (`csv`, `json`, `markdown`, `txt`, `png`)
12. Import CSV Records (row-by-row summary: total, imported, invalid, duplicate)
13. Exit
14. Settings & Demo Dataset

---

## 9. Web Application Pages & Features

- **Landing (`/`)**: SleepNova brand overview, feature summary, and live dataset snapshot.
- **Dashboard (`/dashboard`)**: KPI cards (Total Records, Average & Weekly Average, Latest Session, Goal Progress %), 7-day & 30-day Chart.js charts, Bedtime Consistency card, Personalized Informational Insights, Threshold Warnings, and Recent Entries.
- **Sleep Logger (`/logger`)**: Real-time Python duration preview across midnight, strict field-level error reporting, quick edit/delete list.
- **Sleep History (`/history`)**: Keyword search, date-range filter, min-hours filter, sorting, pagination, edit/delete confirmation modal, CSV/JSON export, and Bulk CSV Import modal with `.csv` + 2 MB checks and invalid/duplicate breakdown.
- **Analytics (`/analytics`)**: 6 interactive Chart.js charts (Weekly Bar, Monthly Line, Duration Distribution, Weekly Goal Completion Progress, Bedtime Consistency, Wake-up Consistency), Metric Derivation Methodology panel, and Python PNG chart download.
- **Reports (`/reports`)**: Daily/Weekly/Monthly/All History period selector, inline Markdown & Plain-Text previews, and one-click downloads for CSV, JSON, `.md`, `.txt`, and PNG.
- **Settings (`/settings`)**: Configurable goal hours, short/long warning thresholds, bedtime variance alert, date format (`YYYY-MM-DD`, `MM/DD/YYYY`, `DD/MM/YYYY`, `MMM DD, YYYY`), demo banner toggle, and dataset reset/clear controls.

---

## 10. Sleep Calculation & Analytics Methodology

- **Exact Elapsed Duration**: Parses `sleep_date + bedtime` and `wake_date + wake_time` via Python `datetime`, requiring `1 <= minutes <= 1440` (`wake_dt > sleep_dt`).
- **Circular Bedtime Consistency**: Converts bedtimes to signed minute offsets around midnight (e.g., `23:30` -> `-30`, `00:15` -> `+15`) so late-evening and post-midnight bedtimes cluster accurately without wrap-around distortion (`score = max(0, min(100, round(100 - (stdev / 120) * 100, 1)))`).
- **Goal Completion**: Percentage of logged nights meeting `duration_hours >= sleep_goal_hours`, segmented across trailing 7-day blocks for trend analysis.
- **Missing Days Policy**: Unlogged days remain `null` in chart series and are excluded from denominators rather than filled with artificial `0h` values.

---

## 11. Validation & Error Handling

- Strict regex + `datetime.strptime` validation for calendar dates (e.g., rejects `2026-02-30` or `2026-13-40`).
- Rejects negative/zero durations, sessions >24h, future dates (>1 day ahead), invalid settings ranges, oversized CSV uploads (`>2 MB`), and duplicate or overlapping sleep intervals.
- Corrupted JSON triggers automatic timestamped backup creation (`*.corrupted.<timestamp>`) and recovery from `data/sleep_records.csv`.

---

## 12. Automated Tests

Run the full test suite (no external test runner required):

```bash
python3 -m unittest discover -s tests -v
```

Suites cover:
- `tests/test_sleep_logic.py`: Midnight crossing, 12h/24h parsing, invalid dates, zero/negative/>24h rejections, circular bedtime offsets, validation guards.
- `tests/test_storage.py`: Cold-start initialization, CRUD round-trips, corrupted JSON backup + CSV recovery, bulk CSV invalid vs. duplicate counts, 2 MB payload limit, `PermissionError` resilience.
- `tests/test_analytics.py`: Weekly/monthly/executive stats, missing-day honesty, circular bedtime consistency, goal progress, report exports, PNG output.
- `tests/test_api_integration.py`: Full `backend.bridge` lifecycle, all 5 chart kinds, warning engine branches, non-interactive CLI menu execution, Flask diagnostic check.

---

## 13. Troubleshooting

- **Port 3000 already in use**: Stop conflicting Node processes and run `npm run dev`.
- **Flask or Matplotlib `ModuleNotFoundError` locally**: Activate your virtual environment and run `pip install -r requirements.txt`, or use `python3 cli.py` / `npm run dev` which run on pure Python 3.11 stdlib.
- **Empty charts or metrics after clearing records**: Log a new session on `/logger` or restore the 39-record demo dataset in **Settings**.

---

## 14. Hackathon Demo Script (2 Minutes)

1. **Overview (`/dashboard`)**: Show live KPIs (Total Records, Average vs. 7d Weekly Average, Latest Night, Goal Progress %), Monthly Trend, Insights, and Warnings.
2. **Midnight Calculation (`/logger`)**: Enter `22:45` -> `06:45` across dates (`8h 00m` preview), save, then trigger a validation error (e.g., wake before sleep) to show strict validation.
3. **Bulk Import & Recovery (`/history`)**: Open **Bulk CSV Import**, load `sample_mixed_test.csv` (or `data/sample_malformed_import.csv`), and point out the exact split between **Imported**, **Invalid Rows**, and **Duplicates**.
4. **Analytics & Exports (`/analytics`, `/reports`)**: Switch through the 6 charts, inspect Methodology, preview the live `.md` / `.txt` report, and download a Python PNG chart.
5. **Dual Persistence & CLI Proof**: Run `python3 cli.py` -> Option `9` (Executive Summary) to confirm the exact same `data/sleep_records.json` & `data/sleep_records.csv` state appears in the terminal.
