"""Central configuration for the SleepNova Sleep Intelligence Platform."""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR: Path = Path(__file__).resolve().parent

DATA_DIR: Path = Path(os.environ.get("SLEEPNOVA_DATA_DIR", BASE_DIR / "data")).resolve()
EXPORTS_DIR: Path = Path(os.environ.get("SLEEPNOVA_EXPORTS_DIR", BASE_DIR / "exports")).resolve()
LOGS_DIR: Path = Path(os.environ.get("SLEEPNOVA_LOGS_DIR", BASE_DIR / "logs")).resolve()

RECORDS_JSON_PATH: Path = DATA_DIR / "sleep_records.json"
RECORDS_CSV_PATH: Path = DATA_DIR / "sleep_records.csv"
SETTINGS_JSON_PATH: Path = DATA_DIR / "settings.json"
APP_LOG_PATH: Path = LOGS_DIR / "sleepnova.log"

APP_NAME: str = "SleepNova"
APP_TAGLINE: str = "Your Sleep. Your Patterns. Your Insights."
PROJECT_NUMBER: int = 32

MAX_SESSION_MINUTES: int = 24 * 60
MIN_SESSION_MINUTES: int = 1
MAX_NOTES_LENGTH: int = 500
DEFAULT_PAGE_SIZE: int = 12

CSV_HEADERS: list[str] = [
    "id",
    "sleep_date",
    "bedtime",
    "wake_date",
    "wake_time",
    "duration_minutes",
    "duration_hours",
    "notes",
    "is_demo",
    "created_at",
    "updated_at",
]

ALLOWED_DATE_FORMATS: tuple[str, ...] = (
    "YYYY-MM-DD",
    "MM/DD/YYYY",
    "DD/MM/YYYY",
    "MMM DD, YYYY",
)

DEFAULT_SETTINGS: dict[str, object] = {
    "sleep_goal_hours": 8.0,
    "short_sleep_threshold_hours": 5.5,
    "long_sleep_threshold_hours": 10.5,
    "bedtime_variance_threshold_mins": 60,
    "missing_days_threshold": 2,
    "preferred_date_format": "YYYY-MM-DD",
    "default_export_format": "csv",
    "show_demo_banner": True,
    "dashboard_window_days": 7,
}


def ensure_directories() -> None:
    """Ensure required application directories exist safely."""
    for directory in (DATA_DIR, EXPORTS_DIR, LOGS_DIR):
        directory.mkdir(parents=True, exist_ok=True)
