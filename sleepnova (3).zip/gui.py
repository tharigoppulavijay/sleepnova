"""Optional lightweight Tkinter desktop GUI sharing the SleepNova Python backend."""

from __future__ import annotations

import sys

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError:
    tk = None  # type: ignore[assignment]

from backend.analytics import compute_executive_summary
from backend.sleep_logic import format_duration
from backend.storage import load_records, load_settings, reset_to_demo_data, save_record
from backend.validation import ValidationError


def launch_gui() -> None:
    if tk is None:
        print(
            "Tkinter is not installed in this Python environment. "
            "Use the SleepNova web interface or run 'python3 cli.py' instead."
        )
        sys.exit(1)

    if not load_records():
        reset_to_demo_data()

    root = tk.Tk()
    root.title("SleepNova — Desktop Companion")
    root.geometry("820x560")
    root.configure(bg="#080B16")

    header = tk.Label(
        root,
        text="SleepNova · Sleep Routine Analyzer",
        font=("Helvetica", 16, "bold"),
        fg="#F4F5FF",
        bg="#080B16",
    )
    header.pack(pady=12)

    summary_var = tk.StringVar()
    summary_lbl = tk.Label(root, textvariable=summary_var, fg="#54D9C6", bg="#101629", padx=12, pady=8)
    summary_lbl.pack(fill="x", padx=16)

    form_frame = tk.Frame(root, bg="#151D34", padx=12, pady=12)
    form_frame.pack(fill="x", padx=16, pady=10)

    fields: dict[str, tk.Entry] = {}
    for idx, (key, label_txt, default_val) in enumerate(
        [
            ("sleep_date", "Sleep Date (YYYY-MM-DD)", ""),
            ("bedtime", "Bedtime (HH:MM)", "22:30"),
            ("wake_date", "Wake Date (YYYY-MM-DD)", ""),
            ("wake_time", "Wake Time (HH:MM)", "06:30"),
            ("notes", "Notes", ""),
        ]
    ):
        tk.Label(form_frame, text=label_txt, fg="#A0A8C0", bg="#151D34").grid(row=idx, column=0, sticky="w", pady=3)
        entry = tk.Entry(form_frame, width=32)
        entry.insert(0, default_val)
        entry.grid(row=idx, column=1, padx=8, pady=3)
        fields[key] = entry

    tree = ttk.Treeview(root, columns=("id", "sleep_date", "bedtime", "wake_time", "duration"), show="headings")
    for col, title in [("id", "ID"), ("sleep_date", "Sleep Date"), ("bedtime", "Bed"), ("wake_time", "Wake"), ("duration", "Duration")]:
        tree.heading(col, text=title)
        tree.column(col, width=140)
    tree.pack(fill="both", expand=True, padx=16, pady=10)

    def refresh() -> None:
        records = load_records()
        assert isinstance(records, list)
        settings = load_settings()
        summary = compute_executive_summary(records, settings)
        overall = summary["overall"]["stats"]
        summary_var.set(
            f"Records: {overall['record_count']}  |  Total: {overall['total_formatted']}  |  Average: {overall['average_formatted']}"
        )
        for item in tree.get_children():
            tree.delete(item)
        for r in records[:25]:
            tree.insert("", "end", values=(r["id"], r["sleep_date"], r["bedtime"], r["wake_time"], format_duration(int(r["duration_minutes"]))))

    def on_add() -> None:
        try:
            save_record({k: e.get() for k, e in fields.items()})
            refresh()
            messagebox.showinfo("Saved", "Sleep record saved successfully.")
        except ValidationError as exc:
            messagebox.showerror("Validation Error", exc.message)

    tk.Button(form_frame, text="Add Sleep Record", command=on_add, bg="#9585FF", fg="#080B16").grid(row=5, column=1, sticky="w", pady=6)
    refresh()
    root.mainloop()


if __name__ == "__main__":
    launch_gui()
