#!/usr/bin/env python3
"""
SleepNova Interactive Terminal Interface (CLI)
Project #32: Sleep Routine Analyzer | StudentLife Hack

Shares the exact same backend business logic, validation, analytics,
plotting, reporting, and CSV/JSON persistence modules as the web application.
"""

from __future__ import annotations

from datetime import date, timedelta
import math
from pathlib import Path
import sys
from typing import Callable

from backend.analytics import (
    compute_executive_summary,
    compute_monthly_analytics,
    compute_weekly_analytics,
)
from backend.plotting import generate_sleep_chart
from backend.reports import build_report_data, export_report_file
from backend.sleep_logic import calculate_duration, format_duration
from backend.storage import (
    delete_record,
    import_csv,
    load_records,
    load_settings,
    reset_to_demo_data,
    save_record,
    save_settings,
    search_records,
    update_record,
)
from backend.validation import ValidationError, validate_date, validate_notes, validate_time

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ACCENT = "\033[38;2;149;133;255m"
TEAL = "\033[38;2;84;217;198m"
AMBER = "\033[38;2;245;158;11m"
RED = "\033[38;2;239;68;68m"
GREEN = "\033[38;2;34;197;94m"


def _c(text: str, color: str) -> str:
    if sys.stdout.isatty():
        return f"{color}{text}{RESET}"
    return text


def print_banner() -> None:
    print()
    print(_c("=" * 78, ACCENT))
    print(_c("  SLEEPNOVA  |  Sleep Routine Analyzer (Project #32)", BOLD + ACCENT))
    print(_c("  Your Sleep. Your Patterns. Your Insights.", DIM))
    print(_c("=" * 78, ACCENT))


def prompt_with_validation(
    label: str,
    validator: Callable[[str], str],
    default: str | None = None,
    allow_cancel: bool = True,
) -> str | None:
    """Centralized input loop preventing crashes from blank or invalid input."""
    hint = f" [{default}]" if default is not None else ""
    cancel_note = " (or 'q' to cancel)" if allow_cancel else ""
    while True:
        try:
            raw = input(f"  {label}{hint}{cancel_note}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Operation cancelled.")
            return None

        if allow_cancel and raw.lower() == "q":
            return None
        if not raw and default is not None:
            raw = default
        try:
            return validator(raw)
        except ValidationError as exc:
            print(_c(f"  [Invalid Input] {exc.message}", RED))
        except ValueError as exc:
            print(_c(f"  [Invalid Input] {exc}", RED))


def prompt_menu_choice(min_val: int, max_val: int) -> int | None:
    """Safely prompt for a numeric menu choice within [min_val, max_val]."""
    while True:
        try:
            raw = input(_c("\n  Select an option: ", BOLD)).strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if not raw:
            print(_c("  Input cannot be blank. Please enter a number.", AMBER))
            continue
        if not raw.isdigit():
            print(_c("  Non-numeric input rejected. Enter a valid menu number.", RED))
            continue
        num = int(raw)
        if num < min_val or num > max_val:
            print(_c(f"  Choice must be between {min_val} and {max_val}.", AMBER))
            continue
        return num


def print_records_table(records: list[dict], page_size: int = 10) -> None:
    """Display records in fixed-width tabular format with interactive pagination."""
    if not records:
        print(_c("\n  No sleep records found.", AMBER))
        return

    total = len(records)
    total_pages = max(1, math.ceil(total / page_size))
    page = 1

    while True:
        start = (page - 1) * page_size
        chunk = records[start : start + page_size]

        print()
        print(
            _c(
                f"  Showing {start + 1}-{min(start + page_size, total)} of {total} record(s) "
                f"(Page {page}/{total_pages})",
                TEAL,
            )
        )
        header = (
            f"  {'ID':<19} {'SLEEP DATE':<11} {'BED':<6} {'WAKE DATE':<11} "
            f"{'WAKE':<6} {'DURATION':<9} {'NOTES'}"
        )
        print(_c("  " + "-" * 96, DIM))
        print(_c(header, BOLD))
        print(_c("  " + "-" * 96, DIM))
        for rec in chunk:
            dur = format_duration(int(rec["duration_minutes"]))
            notes = str(rec.get("notes", ""))
            if len(notes) > 28:
                notes = notes[:25] + "..."
            print(
                f"  {str(rec['id']):<19} {str(rec['sleep_date']):<11} "
                f"{str(rec['bedtime']):<6} {str(rec['wake_date']):<11} "
                f"{str(rec['wake_time']):<6} {dur:<9} {notes}"
            )
        print(_c("  " + "-" * 96, DIM))

        if total_pages == 1:
            break
        try:
            nav = input("  Pagination: [n]ext, [p]rev, or [Enter] to return: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break
        if nav == "n" and page < total_pages:
            page += 1
        elif nav == "p" and page > 1:
            page -= 1
        elif nav in ("", "q"):
            break
        else:
            print(_c("  Already at boundary page or unrecognized key.", AMBER))


def handle_add_record() -> None:
    print(_c("\n--- Add Sleep Record ---", BOLD + ACCENT))
    default_wake = date.today().isoformat()
    default_sleep = (date.today() - timedelta(days=1)).isoformat()

    sleep_date = prompt_with_validation(
        "Sleep start date (YYYY-MM-DD)",
        lambda v: validate_date(v, "Sleep start date"),
        default=default_sleep,
    )
    if sleep_date is None:
        return

    bedtime = prompt_with_validation(
        "Bedtime (HH:MM or HH:MM AM/PM)",
        lambda v: validate_time(v, "Bedtime"),
        default="22:30",
    )
    if bedtime is None:
        return

    wake_date = prompt_with_validation(
        "Wake-up date (YYYY-MM-DD)",
        lambda v: validate_date(v, "Wake-up date"),
        default=default_wake,
    )
    if wake_date is None:
        return

    wake_time = prompt_with_validation(
        "Wake-up time (HH:MM or HH:MM AM/PM)",
        lambda v: validate_time(v, "Wake-up time"),
        default="06:30",
    )
    if wake_time is None:
        return

    notes = prompt_with_validation(
        "Notes (optional)",
        validate_notes,
        default="",
    )
    if notes is None:
        return

    try:
        preview = calculate_duration(sleep_date, bedtime, wake_date, wake_time)
        print(_c(f"\n  Calculated Duration Preview: {preview['formatted']} ({preview['duration_hours']} hrs)", TEAL))
        confirm = input("  Save this record? [Y/n]: ").strip().lower()
        if confirm == "n":
            print("  Cancelled without saving.")
            return
        saved = save_record(
            {
                "sleep_date": sleep_date,
                "bedtime": bedtime,
                "wake_date": wake_date,
                "wake_time": wake_time,
                "notes": notes,
            }
        )
        print(_c(f"  [Saved] Record {saved['id']} persisted to JSON & CSV.", GREEN))
    except (ValidationError, ValueError) as exc:
        print(_c(f"  [Rejected] {exc}", RED))


def handle_view_all() -> None:
    print(_c("\n--- All Sleep Records ---", BOLD + ACCENT))
    res = search_records(sort_order="newest")
    print_records_table(res["records"], page_size=10)


def handle_search_records() -> None:
    print(_c("\n--- Search & Filter Records ---", BOLD + ACCENT))
    keyword = input("  Keyword (notes/ID/date, blank for any): ").strip()
    start_date = input("  Start sleep date (YYYY-MM-DD, blank for any): ").strip()
    end_date = input("  End sleep date (YYYY-MM-DD, blank for any): ").strip()
    min_h_raw = input("  Minimum duration hours (blank for any): ").strip()

    min_hours = None
    if min_h_raw:
        try:
            min_hours = float(min_h_raw)
        except ValueError:
            print(_c("  Invalid numeric value for minimum hours; ignoring filter.", AMBER))

    res = search_records(
        keyword=keyword,
        start_date=start_date,
        end_date=end_date,
        min_hours=min_hours,
        sort_order="newest",
    )
    print_records_table(res["records"], page_size=10)


def handle_edit_record() -> None:
    print(_c("\n--- Edit Sleep Record ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    if not records:
        print(_c("  No records available to edit.", AMBER))
        return

    print_records_table(records[:10], page_size=10)
    record_id = input("  Enter Record ID to edit (or 'q' to cancel): ").strip()
    if not record_id or record_id.lower() == "q":
        return

    target = next((r for r in records if r["id"] == record_id), None)
    if not target:
        print(_c(f"  Record '{record_id}' not found.", RED))
        return

    sleep_date = prompt_with_validation(
        "Sleep start date",
        lambda v: validate_date(v, "Sleep start date"),
        default=str(target["sleep_date"]),
    )
    if sleep_date is None:
        return
    bedtime = prompt_with_validation(
        "Bedtime",
        lambda v: validate_time(v, "Bedtime"),
        default=str(target["bedtime"]),
    )
    if bedtime is None:
        return
    wake_date = prompt_with_validation(
        "Wake-up date",
        lambda v: validate_date(v, "Wake-up date"),
        default=str(target["wake_date"]),
    )
    if wake_date is None:
        return
    wake_time = prompt_with_validation(
        "Wake-up time",
        lambda v: validate_time(v, "Wake-up time"),
        default=str(target["wake_time"]),
    )
    if wake_time is None:
        return
    notes = prompt_with_validation("Notes", validate_notes, default=str(target.get("notes", "")))
    if notes is None:
        return

    try:
        updated = update_record(
            record_id,
            {
                "sleep_date": sleep_date,
                "bedtime": bedtime,
                "wake_date": wake_date,
                "wake_time": wake_time,
                "notes": notes,
            },
        )
        print(_c(f"  [Updated] {updated['id']} -> {format_duration(int(updated['duration_minutes']))}", GREEN))
    except (ValidationError, KeyError, ValueError) as exc:
        print(_c(f"  [Error] {exc}", RED))


def handle_delete_record() -> None:
    print(_c("\n--- Delete Sleep Record ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    if not records:
        print(_c("  No records available to delete.", AMBER))
        return

    print_records_table(records[:10], page_size=10)
    record_id = input("  Enter Record ID to delete (or 'q' to cancel): ").strip()
    if not record_id or record_id.lower() == "q":
        return

    confirm = input(f"  Confirm permanent deletion of '{record_id}'? [y/N]: ").strip().lower()
    if confirm != "y":
        print("  Deletion cancelled.")
        return

    try:
        deleted = delete_record(record_id)
        print(_c(f"  [Deleted] Removed record {deleted['id']}.", GREEN))
    except (ValidationError, KeyError) as exc:
        print(_c(f"  [Error] {exc}", RED))


def handle_daily_summary() -> None:
    print(_c("\n--- Daily Sleep Summary ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()
    report = build_report_data(records, settings, period="daily")
    print(f"  Reference Date    : {report['period_label']}")
    print(f"  Sessions Today    : {report['record_count']}")
    print(f"  Total Today       : {report['total_duration']} ({report['total_hours']} hrs)")
    if report["record_count"] == 0 and records:
        latest = records[0]
        print(
            _c(
                f"  Latest Logged     : {latest['sleep_date']} ({latest['bedtime']} -> {latest['wake_time']}, "
                f"{format_duration(int(latest['duration_minutes']))})",
                TEAL,
            )
        )


def handle_weekly_summary() -> None:
    print(_c("\n--- Weekly Sleep Summary (7 Days) ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()
    weekly = compute_weekly_analytics(records, settings)
    stats = weekly["stats"]
    print(f"  Period            : {weekly['period_start']} to {weekly['period_end']}")
    print(f"  Records Logged    : {stats['record_count']} (Missing days: {weekly['missing_days_count']})")
    print(f"  Total Sleep       : {stats['total_formatted']} ({stats['total_hours']} hrs)")
    print(f"  Weekly Average    : {stats['average_formatted']} ({stats['average_hours']} hrs)")
    print(f"  Goal Attainment   : {stats['goal_achievement_pct']}% (target {stats['goal_hours']}h)")
    print(_c("\n  Daily Breakdown:", BOLD))
    for day in weekly["daily_series"]:
        dur_str = f"{day['duration_hours']:.2f}h" if day["has_record"] else "No record"
        print(f"    {day['label']:<12} | {dur_str}")


def handle_monthly_summary() -> None:
    print(_c("\n--- Monthly Sleep Summary (30 Days) ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()
    monthly = compute_monthly_analytics(records, settings)
    stats = monthly["stats"]
    print(f"  Period            : {monthly['period_start']} to {monthly['period_end']}")
    print(f"  Records Logged    : {stats['record_count']}")
    print(f"  Total Sleep       : {stats['total_formatted']} ({stats['total_hours']} hrs)")
    print(f"  Monthly Average   : {stats['average_formatted']} (Median {stats['median_hours']}h)")
    print(_c("\n  30-Day Duration Distribution:", BOLD))
    for bucket in monthly["distribution"]:
        bar = "#" * bucket["count"]
        print(f"    {bucket['label']:<9} | {bucket['count']:>2}  {_c(bar, ACCENT)}")


def handle_executive_summary() -> None:
    print(_c("\n--- Executive Summary ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()
    summary = compute_executive_summary(records, settings)

    overall = summary["overall"]["stats"]
    weekly = summary["weekly"]["stats"]
    monthly = summary["monthly"]["stats"]
    cons = summary["overall"]["consistency"]

    print(f"  Generated At      : {summary['generated_at']}")
    print(
        f"  Total Records     : {overall['record_count']} "
        f"(User: {summary['data_quality']['user_records']}, Demo: {summary['data_quality']['demo_records']})"
    )
    print(f"  Total Sleep       : {overall['total_formatted']} ({overall['total_hours']} hrs)")
    print(f"  Overall Average   : {overall['average_formatted']} ({overall['average_hours']} hrs)")
    print(f"  7-Day Average     : {weekly['average_formatted']} ({weekly['record_count']} sessions)")
    print(f"  30-Day Average    : {monthly['average_formatted']} ({monthly['record_count']} sessions)")
    if overall["longest_session"]:
        print(f"  Longest Session   : {overall['longest_session']['formatted']} on {overall['longest_session']['sleep_date']}")
        print(f"  Shortest Session  : {overall['shortest_session']['formatted']} on {overall['shortest_session']['sleep_date']}")
    if cons["sufficient_data"]:
        print(
            f"  Consistency Index : {cons['consistency_score']}% ({cons['rating_label']}) "
            f"| Avg Bed {cons['average_bedtime']} (sd {cons['bedtime_stdev_minutes']}m)"
        )
    print(f"  Trend Status      : {summary['trend']['status']} — {summary['trend']['detail']}")

    print(_c("\n  Insights:", BOLD))
    for ins in summary.get("insights", []):
        print(f"   - {ins['title']}: {ins['detail']}")

    print(_c("\n  Threshold Indicators:", BOLD))
    for w in summary["warnings"]:
        color = AMBER if w["severity"] == "warning" else (GREEN if w["severity"] == "nominal" else TEAL)
        print(_c(f"   - [{w['severity'].upper()}] {w['title']}: {w['message']}", color))


def handle_generate_charts() -> None:
    print(_c("\n--- Generate Analytical PNG Charts ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()
    print(
        "  Chart Types: [1] Weekly Trend  [2] Monthly Trend  "
        "[3] Duration Distribution  [4] Goal Progress  [5] Consistency Trend"
    )
    choice = prompt_menu_choice(1, 5)
    if choice is None:
        return
    kind = {
        1: "weekly_trend",
        2: "monthly_trend",
        3: "duration_distribution",
        4: "goal_progress",
        5: "consistency_trend",
    }[choice]
    meta = generate_sleep_chart(records, settings, chart_kind=kind)
    print(_c(f"  [Chart Saved] {meta['path']} (engine: {meta['engine']})", GREEN))


def handle_export_reports() -> None:
    print(_c("\n--- Export Reports ---", BOLD + ACCENT))
    records = load_records()
    assert isinstance(records, list)
    settings = load_settings()

    print("  Periods : [1] Daily  [2] Weekly  [3] Monthly  [4] Complete History")
    p_choice = prompt_menu_choice(1, 4)
    if p_choice is None:
        return
    period = {1: "daily", 2: "weekly", 3: "monthly", 4: "all"}[p_choice]

    print("  Formats : [1] CSV  [2] JSON  [3] Markdown  [4] Plain-Text Audit Log  [5] PNG Chart")
    f_choice = prompt_menu_choice(1, 5)
    if f_choice is None:
        return
    fmt = {1: "csv", 2: "json", 3: "markdown", 4: "txt", 5: "png"}[f_choice]

    result = export_report_file(records, settings, period=period, export_format=fmt)
    print(_c(f"  [Exported] {result['path']}", GREEN))


def handle_bulk_csv_import() -> None:
    print(_c("\n--- Bulk CSV Import ---", BOLD + ACCENT))
    raw_path = input("  Path to CSV file (e.g., data/sample_malformed_import.csv): ").strip()
    if not raw_path:
        print(_c("  Path cannot be blank.", RED))
        return
    path = Path(raw_path)
    if not path.exists() or not path.is_file():
        print(_c(f"  File not found: {raw_path}", RED))
        return
    if path.suffix.lower() != ".csv":
        print(_c("  Only .csv files are accepted for bulk import.", RED))
        return
    try:
        res = import_csv(path)
        print(
            _c(
                f"  Import Summary -> Total rows: {res['total_rows']} | "
                f"Imported: {res['imported_count']} | "
                f"Invalid: {res['invalid_count']} | Duplicates: {res['duplicate_count']}",
                TEAL,
            )
        )
        for err in res["error_logs"]:
            print(_c(f"   Row {err['row']} [{err['category']}]: {err['error']}", AMBER))
    except ValidationError as exc:
        print(_c(f"  [Import Error] {exc.message}", RED))


def handle_settings_and_demo() -> None:
    print(_c("\n--- Settings & Dataset Management ---", BOLD + ACCENT))
    settings = load_settings()
    print(f"  Current Sleep Goal : {settings['sleep_goal_hours']} hrs")
    print(f"  Short Threshold    : {settings['short_sleep_threshold_hours']} hrs")
    print(f"  Long Threshold     : {settings['long_sleep_threshold_hours']} hrs")
    print("  Actions: [1] Update Sleep Goal  [2] Reset to 39-Record Demo Dataset  [3] Back")
    choice = prompt_menu_choice(1, 3)
    if choice == 1:
        raw_goal = input("  New sleep goal in hours (4.0 - 12.0): ").strip()
        try:
            settings["sleep_goal_hours"] = float(raw_goal)
            saved = save_settings(settings)
            print(_c(f"  [Saved] Sleep goal updated to {saved['sleep_goal_hours']} hrs.", GREEN))
        except (ValueError, ValidationError) as exc:
            print(_c(f"  [Rejected] {exc}", RED))
    elif choice == 2:
        confirm = input("  Replace current records with 39 demo records? [y/N]: ").strip().lower()
        if confirm == "y":
            recs = reset_to_demo_data()
            print(_c(f"  [Reset] Seeded {len(recs)} demonstration records.", GREEN))


def main() -> None:
    meta = load_records(include_meta=True)
    assert isinstance(meta, dict)
    if not meta["records"]:
        reset_to_demo_data()
    elif meta.get("recovery_notice"):
        print(_c(f"\n  [Storage Notice] {meta['recovery_notice']}", AMBER))

    print_banner()

    while True:
        print(_c("\n  MAIN MENU", BOLD))
        print("   1. Add Sleep Record")
        print("   2. View All Records")
        print("   3. Search Records")
        print("   4. Edit Record")
        print("   5. Delete Record")
        print("   6. Display Daily Summary")
        print("   7. Display Weekly Summary")
        print("   8. Display Monthly Summary")
        print("   9. Display Executive Summary")
        print("  10. Generate Charts (PNG)")
        print("  11. Export Reports")
        print("  12. Import CSV Records")
        print("  13. Exit")
        print(_c("  14. Settings & Demo Dataset", DIM))

        choice = prompt_menu_choice(1, 14)
        if choice is None or choice == 13:
            print(_c("\n  Thank you for using SleepNova. Sleep well.\n", ACCENT))
            break

        handlers = {
            1: handle_add_record,
            2: handle_view_all,
            3: handle_search_records,
            4: handle_edit_record,
            5: handle_delete_record,
            6: handle_daily_summary,
            7: handle_weekly_summary,
            8: handle_monthly_summary,
            9: handle_executive_summary,
            10: handle_generate_charts,
            11: handle_export_reports,
            12: handle_bulk_csv_import,
            14: handle_settings_and_demo,
        }
        handlers[choice]()


if __name__ == "__main__":
    main()
