"""Defensive server-side input validation and sanitization for SleepNova."""

from __future__ import annotations

from datetime import date, datetime, timedelta
import re
from typing import Any

import config
from .sleep_logic import calculate_duration, parse_sleep_datetimes

DATE_ISO_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
DATE_SLASH_RE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
TIME_24_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
TIME_12_RE = re.compile(r"^(0?[1-9]|1[0-2]):([0-5]\d)\s*(AM|PM)$", re.IGNORECASE)
RECORD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{3,40}$")


class ValidationError(ValueError):
    """Structured validation exception carrying field-level messages."""

    def __init__(self, message: str, field_errors: dict[str, str] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.field_errors = field_errors or {}


def validate_record_id(record_id: Any) -> str:
    """Validate safe record identifier format."""
    if not isinstance(record_id, str) or not record_id.strip():
        raise ValidationError("Record ID is required.", {"id": "Record ID cannot be blank."})
    cleaned = record_id.strip()
    if not RECORD_ID_RE.match(cleaned):
        raise ValidationError(
            "Invalid record ID format.",
            {"id": "Record ID may only contain letters, numbers, hyphens, and underscores."},
        )
    return cleaned


def validate_date(raw_value: Any, field_label: str = "Date", allow_future: bool = False) -> str:
    """
    Validate and normalize a date string to YYYY-MM-DD.

    Supports YYYY-MM-DD and MM/DD/YYYY (unambiguous ISO preferred).
    """
    if not isinstance(raw_value, str) or not raw_value.strip():
        raise ValidationError(f"{field_label} is required.")

    cleaned = raw_value.strip()
    parsed: date | None = None

    if DATE_ISO_RE.match(cleaned):
        try:
            parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
        except ValueError as exc:
            raise ValidationError(f"{field_label} is not a valid calendar date.") from exc
    elif DATE_SLASH_RE.match(cleaned):
        try:
            parsed = datetime.strptime(cleaned, "%m/%d/%Y").date()
        except ValueError:
            try:
                parsed = datetime.strptime(cleaned, "%d/%m/%Y").date()
            except ValueError as exc:
                raise ValidationError(f"{field_label} is not a valid calendar date.") from exc
    else:
        raise ValidationError(
            f"{field_label} must use YYYY-MM-DD format (e.g., 2026-11-23)."
        )

    if parsed.year < 2000 or parsed.year > 2100:
        raise ValidationError(f"{field_label} year must be between 2000 and 2100.")

    if not allow_future:
        max_allowed = date.today() + timedelta(days=1)
        if parsed > max_allowed:
            raise ValidationError(
                f"{field_label} ({parsed.isoformat()}) cannot be in the future."
            )

    return parsed.isoformat()


def validate_time(raw_value: Any, field_label: str = "Time") -> str:
    """
    Validate a clock time and normalize to 24-hour HH:MM.

    Accepts 24-hour 'HH:MM' and 12-hour 'HH:MM AM/PM'.
    """
    if not isinstance(raw_value, str) or not raw_value.strip():
        raise ValidationError(f"{field_label} is required.")

    cleaned = raw_value.strip()

    match_24 = TIME_24_RE.match(cleaned)
    if match_24:
        hour = int(match_24.group(1))
        minute = int(match_24.group(2))
        return f"{hour:02d}:{minute:02d}"

    match_12 = TIME_12_RE.match(cleaned)
    if match_12:
        hour = int(match_12.group(1))
        minute = int(match_12.group(2))
        period = match_12.group(3).upper()
        if period == "AM":
            hour = 0 if hour == 12 else hour
        else:
            hour = 12 if hour == 12 else hour + 12
        return f"{hour:02d}:{minute:02d}"

    raise ValidationError(
        f"{field_label} must be a valid time in HH:MM (24-hour) or HH:MM AM/PM format."
    )


def validate_notes(raw_notes: Any) -> str:
    """Sanitize optional user notes without corrupting ordinary punctuation."""
    if raw_notes is None:
        return ""
    if not isinstance(raw_notes, str):
        raise ValidationError("Notes must be plain text.")
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", raw_notes).strip()
    if len(cleaned) > config.MAX_NOTES_LENGTH:
        raise ValidationError(
            f"Notes must be {config.MAX_NOTES_LENGTH} characters or fewer."
        )
    return cleaned


def sanitize_csv_cell(value: str) -> str:
    """Neutralize spreadsheet formula injection prefixes when exporting CSV cells."""
    if value and value[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def check_duplicate_record(
    sleep_date: str,
    bedtime: str,
    wake_date: str,
    wake_time: str,
    existing_records: list[dict[str, Any]],
    exclude_id: str | None = None,
) -> str | None:
    """
    Detect exact duplicate or overlapping sleep intervals against existing records.

    Returns an explanatory error string if a conflict exists, or None if clear.
    """
    new_start, new_end = parse_sleep_datetimes(sleep_date, bedtime, wake_date, wake_time)

    for rec in existing_records:
        if exclude_id and rec.get("id") == exclude_id:
            continue
        try:
            rec_start, rec_end = parse_sleep_datetimes(
                str(rec["sleep_date"]),
                str(rec["bedtime"]),
                str(rec["wake_date"]),
                str(rec["wake_time"]),
            )
        except Exception:
            continue

        if new_start == rec_start and new_end == rec_end:
            return (
                f"Duplicate sleep record detected: an identical session "
                f"({sleep_date} {bedtime} to {wake_date} {wake_time}) already exists "
                f"as {rec.get('id')}."
            )

        # Strict interval overlap check: (startA < endB) and (endA > startB)
        if new_start < rec_end and new_end > rec_start:
            return (
                f"Overlapping sleep session detected with record {rec.get('id')} "
                f"({rec.get('sleep_date')} {rec.get('bedtime')} to "
                f"{rec.get('wake_date')} {rec.get('wake_time')})."
            )

    return None


def validate_sleep_record_input(
    payload: dict[str, Any],
    existing_records: list[dict[str, Any]] | None = None,
    exclude_id: str | None = None,
    allow_future: bool = False,
) -> dict[str, Any]:
    """
    Validate all fields of a sleep record payload and return normalized values.

    Raises ValidationError with detailed field_errors on any invalid input.
    """
    if not isinstance(payload, dict):
        raise ValidationError("Invalid request payload.")

    field_errors: dict[str, str] = {}

    try:
        sleep_date = validate_date(payload.get("sleep_date"), "Sleep start date", allow_future=allow_future)
    except ValidationError as exc:
        sleep_date = ""
        field_errors["sleep_date"] = exc.message

    try:
        bedtime = validate_time(payload.get("bedtime"), "Bedtime")
    except ValidationError as exc:
        bedtime = ""
        field_errors["bedtime"] = exc.message

    try:
        wake_date = validate_date(payload.get("wake_date"), "Wake-up date", allow_future=allow_future)
    except ValidationError as exc:
        wake_date = ""
        field_errors["wake_date"] = exc.message

    try:
        wake_time = validate_time(payload.get("wake_time"), "Wake-up time")
    except ValidationError as exc:
        wake_time = ""
        field_errors["wake_time"] = exc.message

    try:
        notes = validate_notes(payload.get("notes", ""))
    except ValidationError as exc:
        notes = ""
        field_errors["notes"] = exc.message

    if field_errors:
        first_msg = next(iter(field_errors.values()))
        raise ValidationError(first_msg, field_errors)

    try:
        duration_info = calculate_duration(sleep_date, bedtime, wake_date, wake_time)
    except ValueError:
        msg = (
            f"Wake-up date and time ({wake_date} {wake_time}) must be after "
            f"sleep start ({sleep_date} {bedtime}). For overnight sessions, set "
            f"Wake-up date to the following calendar day."
        )
        raise ValidationError(msg, {"wake_date": msg, "wake_time": msg})

    duration_minutes = int(duration_info["duration_minutes"])
    if duration_minutes < config.MIN_SESSION_MINUTES:
        msg = "Sleep duration must be at least 1 minute."
        raise ValidationError(msg, {"wake_time": msg})

    if duration_minutes > config.MAX_SESSION_MINUTES:
        msg = (
            f"Calculated duration ({duration_info['formatted']}) exceeds the 24-hour "
            f"single-session limit. Please verify your sleep start and wake-up dates."
        )
        raise ValidationError(msg, {"wake_date": msg})

    if existing_records is not None:
        dup_msg = check_duplicate_record(
            sleep_date, bedtime, wake_date, wake_time, existing_records, exclude_id=exclude_id
        )
        if dup_msg:
            raise ValidationError(dup_msg, {"sleep_date": dup_msg})

    return {
        "sleep_date": sleep_date,
        "bedtime": bedtime,
        "wake_date": wake_date,
        "wake_time": wake_time,
        "notes": notes,
        "duration_minutes": duration_minutes,
        "duration_hours": float(duration_info["duration_hours"]),
        "is_demo": bool(payload.get("is_demo", False)),
    }


def validate_settings(payload: dict[str, Any]) -> dict[str, Any]:
    """Validate application configuration and warning threshold settings."""
    if not isinstance(payload, dict):
        raise ValidationError("Settings payload must be an object.")

    defaults = dict(config.DEFAULT_SETTINGS)
    merged: dict[str, Any] = {}

    def _float_in_range(key: str, min_val: float, max_val: float, label: str) -> float:
        raw = payload.get(key, defaults[key])
        try:
            val = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"{label} must be a valid number.", {key: f"{label} must be a number."}) from exc
        if val < min_val or val > max_val:
            raise ValidationError(
                f"{label} must be between {min_val} and {max_val}.",
                {key: f"Must be between {min_val} and {max_val}."},
            )
        return round(val, 2)

    def _int_in_range(key: str, min_val: int, max_val: int, label: str) -> int:
        raw = payload.get(key, defaults[key])
        try:
            val = int(raw)
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"{label} must be an integer.", {key: f"{label} must be an integer."}) from exc
        if val < min_val or val > max_val:
            raise ValidationError(
                f"{label} must be between {min_val} and {max_val}.",
                {key: f"Must be between {min_val} and {max_val}."},
            )
        return val

    merged["sleep_goal_hours"] = _float_in_range("sleep_goal_hours", 4.0, 12.0, "Sleep goal (hours)")
    merged["short_sleep_threshold_hours"] = _float_in_range(
        "short_sleep_threshold_hours", 1.0, 9.0, "Short sleep warning threshold"
    )
    merged["long_sleep_threshold_hours"] = _float_in_range(
        "long_sleep_threshold_hours", 7.0, 18.0, "Long sleep warning threshold"
    )

    if merged["short_sleep_threshold_hours"] >= merged["long_sleep_threshold_hours"]:
        raise ValidationError(
            "Short sleep threshold must be lower than long sleep threshold.",
            {"short_sleep_threshold_hours": "Must be less than long sleep threshold."},
        )

    merged["bedtime_variance_threshold_mins"] = _int_in_range(
        "bedtime_variance_threshold_mins", 15, 240, "Bedtime variance threshold (minutes)"
    )
    merged["missing_days_threshold"] = _int_in_range(
        "missing_days_threshold", 1, 14, "Missing logging days alert"
    )
    merged["dashboard_window_days"] = _int_in_range(
        "dashboard_window_days", 7, 30, "Dashboard trend window"
    )

    date_fmt = str(payload.get("preferred_date_format", defaults["preferred_date_format"]))
    if date_fmt not in config.ALLOWED_DATE_FORMATS:
        raise ValidationError(
            f"Unsupported date format: {date_fmt}.",
            {"preferred_date_format": "Select a supported date format."},
        )
    merged["preferred_date_format"] = date_fmt

    export_fmt = str(payload.get("default_export_format", defaults["default_export_format"])).lower()
    if export_fmt not in ("csv", "json", "markdown", "txt"):
        raise ValidationError(
            "Default export format must be csv, json, markdown, or txt.",
            {"default_export_format": "Invalid export format."},
        )
    merged["default_export_format"] = export_fmt
    merged["show_demo_banner"] = bool(payload.get("show_demo_banner", defaults["show_demo_banner"]))

    return merged
