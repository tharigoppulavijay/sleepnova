"""Analytical chart generator using Matplotlib with pure-Python PNG fallback."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import struct
from typing import Any
import zlib

import config
from .analytics import compute_monthly_analytics, compute_weekly_analytics

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


def _encode_png(width: int, height: int, rgb_bytes: bytearray) -> bytes:
    """Encode an RGB framebuffer into a valid PNG file using Python stdlib zlib."""

    def chunk(tag: bytes, data: bytes) -> bytes:
        crc = zlib.crc32(tag + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)

    raw_rows = bytearray()
    stride = width * 3
    for y in range(height):
        raw_rows.append(0)  # Filter type 0 (None)
        start = y * stride
        raw_rows.extend(rgb_bytes[start : start + stride])

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    idat = zlib.compress(bytes(raw_rows), level=6)
    return b"".join(
        [
            b"\x89PNG\r\n\x1a\n",
            chunk(b"IHDR", ihdr),
            chunk(b"IDAT", idat),
            chunk(b"IEND", b""),
        ]
    )


def _draw_rect(
    buf: bytearray,
    width: int,
    height: int,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    color: tuple[int, int, int],
) -> None:
    r, g, b = color
    cx0 = max(0, min(width - 1, x0))
    cx1 = max(0, min(width, x1))
    cy0 = max(0, min(height - 1, y0))
    cy1 = max(0, min(height, y1))
    for y in range(cy0, cy1):
        row_offset = y * width * 3
        for x in range(cx0, cx1):
            idx = row_offset + x * 3
            buf[idx] = r
            buf[idx + 1] = g
            buf[idx + 2] = b


def _draw_line(
    buf: bytearray,
    width: int,
    height: int,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    color: tuple[int, int, int],
    thickness: int = 2,
) -> None:
    steps = max(abs(x1 - x0), abs(y1 - y0), 1)
    for i in range(steps + 1):
        t = i / steps
        x = int(round(x0 + (x1 - x0) * t))
        y = int(round(y0 + (y1 - y0) * t))
        _draw_rect(buf, width, height, x - thickness // 2, y - thickness // 2, x + thickness // 2 + 1, y + thickness // 2 + 1, color)


def _fallback_png_chart(
    series: list[tuple[str, float | None]],
    goal_hours: float,
    output_path: Path,
    mode: str = "bar",
) -> Path:
    """
    Pure-Python PNG chart fallback when Matplotlib is unavailable in the runtime.
    Renders SleepNova's exact dark-mode palette (#080B16 bg, #9585FF bars, #54D9C6 goal).
    """
    width, height = 960, 480
    bg = (8, 11, 22)
    surface = (21, 29, 52)
    grid = (36, 46, 78)
    accent = (149, 133, 255)
    teal = (84, 217, 198)

    buf = bytearray(bg * (width * height))
    pad_l, pad_r, pad_t, pad_b = 70, 40, 45, 55
    plot_w = width - pad_l - pad_r
    plot_h = height - pad_t - pad_b

    _draw_rect(buf, width, height, pad_l, pad_t, width - pad_r, height - pad_b, surface)

    max_hours = 12.0
    for h_tick in (2, 4, 6, 8, 10, 12):
        y = int(height - pad_b - (h_tick / max_hours) * plot_h)
        _draw_line(buf, width, height, pad_l, y, width - pad_r, y, grid, 1)

    goal_y = int(height - pad_b - (min(goal_hours, max_hours) / max_hours) * plot_h)
    _draw_line(buf, width, height, pad_l, goal_y, width - pad_r, goal_y, teal, 2)

    n = max(1, len(series))
    slot_w = plot_w / n
    points: list[tuple[int, int]] = []
    for idx, (_lbl, val) in enumerate(series):
        if val is None:
            continue
        clamped = max(0.0, min(max_hours, float(val)))
        bar_h = int((clamped / max_hours) * plot_h)
        cx = int(pad_l + idx * slot_w + slot_w / 2)
        cy = height - pad_b - bar_h
        if mode == "bar":
            bw = max(6, int(slot_w * 0.56))
            color = teal if clamped >= goal_hours else accent
            _draw_rect(buf, width, height, cx - bw // 2, cy, cx + bw // 2, height - pad_b, color)
        else:
            points.append((cx, cy))

    if mode == "line" and len(points) >= 2:
        for i in range(len(points) - 1):
            _draw_line(buf, width, height, points[i][0], points[i][1], points[i + 1][0], points[i + 1][1], accent, 3)
        for px, py in points:
            _draw_rect(buf, width, height, px - 4, py - 4, px + 5, py + 5, teal)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(_encode_png(width, height, buf))
    return output_path


def generate_sleep_chart(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    chart_kind: str = "weekly_trend",
    output_path: Path | None = None,
) -> dict[str, Any]:
    """
    Generate an analytical PNG chart using Matplotlib (with stdlib fallback on ImportError).

    Supported chart_kind values:
    - weekly_trend
    - monthly_trend
    - duration_distribution
    - goal_progress
    - consistency_trend
    """
    config.ensure_directories()
    valid_kinds = (
        "weekly_trend",
        "monthly_trend",
        "duration_distribution",
        "goal_progress",
        "consistency_trend",
    )
    kind = chart_kind if chart_kind in valid_kinds else "weekly_trend"

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = output_path or (config.EXPORTS_DIR / f"sleepnova_{kind}_{stamp}.png")
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))
    use_goal_line = True
    y_label = "Duration (Hours)"

    if kind == "weekly_trend":
        weekly = compute_weekly_analytics(records, settings)
        series = [(d["label"], d["duration_hours"]) for d in weekly["daily_series"]]
        title = f"SleepNova Weekly Sleep Duration ({weekly['period_start']} to {weekly['period_end']})"
        mode = "bar"
    elif kind == "monthly_trend":
        monthly = compute_monthly_analytics(records, settings)
        series = [(d["label"], d["duration_hours"]) for d in monthly["daily_series"]]
        title = f"SleepNova 30-Day Sleep Trend ({monthly['period_start']} to {monthly['period_end']})"
        mode = "line"
    elif kind == "goal_progress":
        monthly = compute_monthly_analytics(records, settings)
        series = []
        for wk in monthly["weekly_comparison"]:
            pct = min(100.0, round((wk["average_hours"] / max(1.0, goal_hours)) * 100.0, 1)) if wk["record_count"] else 0.0
            series.append((wk["label"], pct))
        title = f"SleepNova Weekly Goal Attainment vs {goal_hours}h Target (%)"
        mode = "bar"
        use_goal_line = False
        y_label = "Goal Attainment (%)"
    elif kind == "consistency_trend":
        monthly = compute_monthly_analytics(records, settings)
        series = [(pt["date"][5:], pt["bedtime_offset_hours"] + 6.0) for pt in monthly["consistency_series"]]
        if not series:
            series = [("No Data", None)]
        title = "SleepNova Bedtime Consistency Trend (Shifted +6h)"
        mode = "line"
        use_goal_line = False
        y_label = "Bedtime Offset (+6h)"
    else:
        monthly = compute_monthly_analytics(records, settings)
        series = [(b["label"], float(b["count"])) for b in monthly["distribution"]]
        title = "SleepNova Duration Distribution (Last 30 Days)"
        mode = "bar"
        use_goal_line = False
        y_label = "Sessions"

    if not MATPLOTLIB_AVAILABLE:
        _fallback_png_chart(series, goal_hours if use_goal_line else 0.0, target, mode=mode)
        return {
            "path": str(target),
            "filename": target.name,
            "engine": "stdlib_png_fallback",
            "chart_kind": kind,
        }

    # Full Matplotlib dark-theme rendering
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    fig.patch.set_facecolor("#080B16")
    ax.set_facecolor("#151D34")

    labels = [item[0] for item in series]
    values = [item[1] for item in series]

    if mode == "bar":
        numeric_vals = [v if v is not None else 0.0 for v in values]
        colors = [
            "#54D9C6" if (use_goal_line and v >= goal_hours) or (kind == "goal_progress" and v >= 100.0) else "#9585FF"
            for v in numeric_vals
        ]
        bars = ax.bar(range(len(labels)), numeric_vals, color=colors, width=0.58, zorder=3)
        for bar, orig in zip(bars, values):
            if orig is None:
                bar.set_alpha(0.0)
        if use_goal_line:
            ax.axhline(goal_hours, color="#54D9C6", linestyle="--", linewidth=1.4, label=f"Goal ({goal_hours}h)", zorder=4)
        ax.set_ylabel(y_label, color="#F4F5FF")
    else:
        valid_x = [i for i, v in enumerate(values) if v is not None]
        valid_y = [float(v) for v in values if v is not None]
        if valid_x:
            ax.plot(valid_x, valid_y, color="#9585FF", linewidth=2.2, marker="o", markersize=4, label=y_label, zorder=3)
            ax.fill_between(valid_x, valid_y, color="#9585FF", alpha=0.14, zorder=2)
        if use_goal_line:
            ax.axhline(goal_hours, color="#54D9C6", linestyle="--", linewidth=1.4, label=f"Goal ({goal_hours}h)", zorder=4)
        ax.set_ylabel(y_label, color="#F4F5FF")

    step = max(1, len(labels) // 8)
    ax.set_xticks(range(0, len(labels), step))
    ax.set_xticklabels([labels[i] for i in range(0, len(labels), step)], rotation=25, ha="right", color="#A0A8C0", fontsize=9)
    ax.tick_params(axis="y", colors="#A0A8C0")
    ax.set_title(title, color="#F4F5FF", fontsize=12, fontweight="bold", pad=14)
    ax.grid(axis="y", color="#232D4B", linestyle="-", linewidth=0.7, zorder=1)
    for spine in ax.spines.values():
        spine.set_color("#2A3558")

    handles, legend_labels = ax.get_legend_handles_labels()
    if handles:
        ax.legend(facecolor="#101629", edgecolor="#2A3558", labelcolor="#F4F5FF", fontsize=9)

    fig.tight_layout()
    target.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(target, facecolor=fig.get_facecolor())
    plt.close(fig)

    return {
        "path": str(target),
        "filename": target.name,
        "engine": "matplotlib",
        "chart_kind": kind,
    }
