"""Configurable threshold warning indicators (non-diagnostic, informational)."""

from __future__ import annotations

from datetime import date, datetime, timedelta
import statistics
from typing import Any

from .sleep_logic import compute_bedtime_offset_minutes, format_duration


def evaluate_warnings(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    reference_date: date | None = None,
) -> list[dict[str, Any]]:
    """
    Evaluate stored sleep records against user-configured threshold settings.

    Returns structured, non-alarming informational and warning indicators.
    Never diagnoses health conditions.
    """
    warnings: list[dict[str, Any]] = []
    if not records:
        return [
            {
                "id": "no-records",
                "severity": "info",
                "category": "onboarding",
                "title": "No sleep records logged yet",
                "message": "Log your first sleep session or load the demonstration dataset to view trend alerts.",
                "record_ids": [],
            }
        ]

    today = reference_date or date.today()
    short_limit = float(settings.get("short_sleep_threshold_hours", 5.5))
    long_limit = float(settings.get("long_sleep_threshold_hours", 10.5))
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))
    bedtime_var_limit = int(settings.get("bedtime_variance_threshold_mins", 60))
    missing_days_limit = int(settings.get("missing_days_threshold", 2))

    # 1. Recent short/long session checks (last 14 days or latest 14 records)
    cutoff_14 = (today - timedelta(days=14)).isoformat()
    recent = [r for r in records if str(r.get("wake_date", "")) >= cutoff_14]
    if not recent:
        recent = records[:14]

    short_sessions = [r for r in recent if float(r.get("duration_hours", 0.0)) < short_limit]
    if short_sessions:
        latest_short = short_sessions[0]
        warnings.append(
            {
                "id": "short-sessions",
                "severity": "warning",
                "category": "duration_low",
                "title": f"{len(short_sessions)} session(s) below {short_limit:.1f}h threshold",
                "message": (
                    f"Most recent short entry on {latest_short['sleep_date']} recorded "
                    f"{format_duration(int(latest_short['duration_minutes']))} "
                    f"(below your {short_limit:.1f}h threshold)."
                ),
                "record_ids": [str(r["id"]) for r in short_sessions[:5]],
            }
        )

    long_sessions = [r for r in recent if float(r.get("duration_hours", 0.0)) > long_limit]
    if long_sessions:
        latest_long = long_sessions[0]
        warnings.append(
            {
                "id": "long-sessions",
                "severity": "warning",
                "category": "duration_high",
                "title": f"{len(long_sessions)} session(s) above {long_limit:.1f}h threshold",
                "message": (
                    f"Entry on {latest_long['sleep_date']} logged "
                    f"{format_duration(int(latest_long['duration_minutes']))}, "
                    f"exceeding your {long_limit:.1f}h review threshold."
                ),
                "record_ids": [str(r["id"]) for r in long_sessions[:5]],
            }
        )

    # 2. Missing expected records / logging gap
    wake_dates = sorted({str(r.get("wake_date", "")) for r in records if r.get("wake_date")})
    if wake_dates:
        latest_wake = datetime.strptime(wake_dates[-1], "%Y-%m-%d").date()
        days_since_last = (today - latest_wake).days
        if days_since_last >= missing_days_limit:
            warnings.append(
                {
                    "id": "logging-gap",
                    "severity": "warning",
                    "category": "missing_records",
                    "title": f"No entries logged in the past {days_since_last} day(s)",
                    "message": (
                        f"Your most recent wake-up entry was {latest_wake.isoformat()}. "
                        f"Consistent daily logging improves weekly trend accuracy."
                    ),
                    "record_ids": [],
                }
            )

    # 3. Irregular bedtime variation across recent 7+ sessions
    if len(recent) >= 3:
        offsets = [compute_bedtime_offset_minutes(str(r["bedtime"])) for r in recent]
        bed_stdev = statistics.stdev(offsets)
        if bed_stdev > bedtime_var_limit:
            warnings.append(
                {
                    "id": "bedtime-variance",
                    "severity": "warning",
                    "category": "consistency",
                    "title": f"Bedtime variation ({round(bed_stdev)}m) exceeds {bedtime_var_limit}m target",
                    "message": (
                        f"Recent bedtimes varied by a standard deviation of {round(bed_stdev)} minutes. "
                        f"A narrower bedtime window raises your schedule consistency."
                    ),
                    "record_ids": [],
                }
            )

    # 4. Goal deviation notice over recent window
    if recent:
        avg_hours = statistics.mean(float(r.get("duration_hours", 0.0)) for r in recent)
        diff = avg_hours - goal_hours
        if abs(diff) >= 0.75:
            direction = "below" if diff < 0 else "above"
            warnings.append(
                {
                    "id": "goal-deviation",
                    "severity": "info",
                    "category": "goal",
                    "title": f"Recent average is {abs(diff):.1f}h {direction} your {goal_hours:.1f}h goal",
                    "message": (
                        f"Across {len(recent)} recent record(s), average duration is "
                        f"{avg_hours:.2f}h compared to your configured {goal_hours:.1f}h target."
                    ),
                    "record_ids": [],
                }
            )

    if not warnings:
        warnings.append(
            {
                "id": "all-nominal",
                "severity": "nominal",
                "category": "status",
                "title": "All routine thresholds within configured range",
                "message": (
                    f"Recent entries stay within {short_limit:.1f}h–{long_limit:.1f}h "
                    f"and bedtime variation is within {bedtime_var_limit} minutes."
                ),
                "record_ids": [],
            }
        )

    return warnings
