"""Multi-format executive report generator (CSV, JSON, Markdown, TXT Audit Log, PNG)."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import config
from .analytics import compute_consistency_metrics, compute_executive_summary
from .plotting import generate_sleep_chart
from .sleep_logic import format_duration
from .storage import export_csv, export_json
from .warnings import evaluate_warnings


def filter_records_by_period(
    records: list[dict[str, Any]],
    period: str = "all",
    reference_date: date | None = None,
) -> tuple[list[dict[str, Any]], str, str]:
    """Filter records by daily, weekly, monthly, or all-time scope."""
    today = reference_date or date.today()
    p = (period or "all").lower()

    if p == "daily":
        start = today
        title = "Daily Sleep Report"
    elif p == "weekly":
        start = today - timedelta(days=6)
        title = "Weekly Sleep Report"
    elif p == "monthly":
        start = today - timedelta(days=29)
        title = "Monthly Sleep Report"
    else:
        p = "all"
        start = date(2000, 1, 1)
        title = "Complete Historical Sleep Report"

    if p == "all":
        filtered = list(records)
        if filtered:
            dates = sorted(str(r["sleep_date"]) for r in filtered)
            period_label = f"{dates[0]} to {dates[-1]}"
        else:
            period_label = "No records available"
    else:
        s_iso = start.isoformat()
        e_iso = today.isoformat()
        filtered = [
            r
            for r in records
            if s_iso <= str(r.get("wake_date", r.get("sleep_date", ""))) <= e_iso
        ]
        period_label = f"{s_iso} to {e_iso}"

    return filtered, title, period_label


def build_report_data(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    period: str = "weekly",
    reference_date: date | None = None,
) -> dict[str, Any]:
    """Assemble structured executive report metrics for the requested period."""
    today = reference_date or date.today()
    scoped, title, period_label = filter_records_by_period(records, period, today)
    summary = compute_executive_summary(records, settings, reference_date=today)
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))

    if scoped:
        total_mins = sum(int(r["duration_minutes"]) for r in scoped)
        avg_mins = round(total_mins / len(scoped))
        longest = max(scoped, key=lambda r: int(r["duration_minutes"]))
        shortest = min(scoped, key=lambda r: int(r["duration_minutes"]))
        goal_met = sum(1 for r in scoped if float(r["duration_hours"]) >= goal_hours)
        goal_pct = round((goal_met / len(scoped)) * 100.0, 1)
    else:
        total_mins = 0
        avg_mins = 0
        longest = None
        shortest = None
        goal_met = 0
        goal_pct = 0.0

    consistency = compute_consistency_metrics(scoped)
    warnings = evaluate_warnings(scoped if scoped else records, settings, reference_date=today)
    demo_count = sum(1 for r in scoped if r.get("is_demo"))

    return {
        "title": title,
        "period": period,
        "period_label": period_label,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "record_count": len(scoped),
        "total_duration": format_duration(total_mins),
        "total_hours": round(total_mins / 60.0, 2),
        "average_duration": format_duration(avg_mins),
        "average_hours": round(avg_mins / 60.0, 2),
        "longest_session": (
            f"{format_duration(int(longest['duration_minutes']))} ({longest['sleep_date']})"
            if longest
            else "N/A"
        ),
        "shortest_session": (
            f"{format_duration(int(shortest['duration_minutes']))} ({shortest['sleep_date']})"
            if shortest
            else "N/A"
        ),
        "goal_hours": goal_hours,
        "goal_met_count": goal_met,
        "goal_achievement_pct": goal_pct,
        "consistency": consistency,
        "trend_summary": summary["trend"]["detail"],
        "data_quality": {
            "total_records": len(scoped),
            "demo_records": demo_count,
            "user_records": len(scoped) - demo_count,
        },
        "warnings": warnings,
        "records": scoped,
    }


def render_markdown_report(report: dict[str, Any]) -> str:
    """Render a structured Markdown executive report."""
    lines: list[str] = [
        f"# SleepNova — {report['title']}",
        "",
        f"- **Reporting Period:** {report['period_label']}",
        f"- **Generated At:** {report['generated_at']}",
        f"- **Records Included:** {report['record_count']}",
        "",
        "## Executive Metrics",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        f"| Total Recorded Sleep | {report['total_duration']} ({report['total_hours']} hrs) |",
        f"| Average Sleep Duration | {report['average_duration']} ({report['average_hours']} hrs) |",
        f"| Longest Session | {report['longest_session']} |",
        f"| Shortest Session | {report['shortest_session']} |",
        f"| Configured Goal | {report['goal_hours']} hrs ({report['goal_met_count']}/{report['record_count']} sessions met · {report['goal_achievement_pct']}%) |",
        "",
        "## Schedule Consistency",
        "",
    ]
    cons = report["consistency"]
    if cons["sufficient_data"]:
        lines.extend(
            [
                f"- **Consistency Index:** {cons['consistency_score']}% ({cons['rating_label']})",
                f"- **Average Bedtime:** {cons['average_bedtime']} (σ = {cons['bedtime_stdev_minutes']} min)",
                f"- **Average Wake Time:** {cons['average_wake_time']} (σ = {cons['wake_stdev_minutes']} min)",
                f"- **Method:** {cons['explanation']}",
            ]
        )
    else:
        lines.append(f"- {cons['explanation']}")

    lines.extend(
        [
            "",
            "## Trend & Data Quality",
            "",
            f"- **Trend Summary:** {report['trend_summary']}",
            f"- **Data Composition:** {report['data_quality']['user_records']} personal record(s), {report['data_quality']['demo_records']} demonstration record(s).",
            "",
            "## Threshold Indicators",
            "",
        ]
    )
    for w in report["warnings"]:
        lines.append(f"- **[{w['severity'].upper()}] {w['title']}**: {w['message']}")

    if report["records"]:
        lines.extend(
            [
                "",
                "## Session Log",
                "",
                "| ID | Sleep Date | Bedtime | Wake Date | Wake Time | Duration | Notes |",
                "| --- | --- | --- | --- | --- | --- | --- |",
            ]
        )
        for rec in report["records"]:
            note_clean = str(rec.get("notes", "")).replace("|", "\\|")
            lines.append(
                f"| {rec['id']} | {rec['sleep_date']} | {rec['bedtime']} | {rec['wake_date']} | {rec['wake_time']} | {format_duration(int(rec['duration_minutes']))} | {note_clean} |"
            )

    return "\n".join(lines) + "\n"


def render_txt_audit_log(report: dict[str, Any]) -> str:
    """Render a plain-text fixed-width audit log report."""
    sep = "=" * 76
    sub = "-" * 76
    lines: list[str] = [
        sep,
        f"SLEEPNOVA AUDIT REPORT :: {report['title'].upper()}",
        sep,
        f"Reporting Period : {report['period_label']}",
        f"Generated At     : {report['generated_at']}",
        f"Records Count    : {report['record_count']}",
        f"Total Duration   : {report['total_duration']} ({report['total_hours']} hrs)",
        f"Average Duration : {report['average_duration']} ({report['average_hours']} hrs)",
        f"Longest Session  : {report['longest_session']}",
        f"Shortest Session : {report['shortest_session']}",
        f"Goal Target      : {report['goal_hours']} hrs ({report['goal_achievement_pct']}% met)",
        sub,
        "CONSISTENCY & TREND",
        sub,
    ]
    cons = report["consistency"]
    if cons["sufficient_data"]:
        lines.append(
            f"Consistency      : {cons['consistency_score']}% ({cons['rating_label']}) | "
            f"Avg Bed {cons['average_bedtime']} (sd {cons['bedtime_stdev_minutes']}m) | "
            f"Avg Wake {cons['average_wake_time']} (sd {cons['wake_stdev_minutes']}m)"
        )
    else:
        lines.append(f"Consistency      : {cons['explanation']}")
    lines.append(f"Trend Summary    : {report['trend_summary']}")
    lines.append(
        f"Data Quality     : {report['data_quality']['user_records']} user / "
        f"{report['data_quality']['demo_records']} demo records"
    )
    lines.extend([sub, "THRESHOLD INDICATORS", sub])
    for w in report["warnings"]:
        lines.append(f"[{w['severity'].upper():7}] {w['title']} - {w['message']}")

    if report["records"]:
        lines.extend(
            [
                sub,
                f"{'ID':18} {'SLEEP DATE':11} {'BED':6} {'WAKE DATE':11} {'WAKE':6} {'DURATION':9} NOTES",
                sub,
            ]
        )
        for rec in report["records"]:
            dur = format_duration(int(rec["duration_minutes"]))
            lines.append(
                f"{str(rec['id']):18} {str(rec['sleep_date']):11} {str(rec['bedtime']):6} "
                f"{str(rec['wake_date']):11} {str(rec['wake_time']):6} {dur:9} {rec.get('notes', '')}"
            )
    lines.append(sep)
    return "\n".join(lines) + "\n"


def export_report_file(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    period: str = "weekly",
    export_format: str = "markdown",
    output_dir: Path | None = None,
) -> dict[str, Any]:
    """Generate and persist a report file in exports/ with a meaningful filename."""
    config.ensure_directories()
    out_dir = output_dir or config.EXPORTS_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    fmt = (export_format or "markdown").lower()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_period = period.lower() if period.lower() in ("daily", "weekly", "monthly", "all") else "all"
    report = build_report_data(records, settings, period=safe_period)

    if fmt == "csv":
        filename = f"sleepnova_{safe_period}_report_{stamp}.csv"
        target = out_dir / filename
        content = export_csv(report["records"], output_path=target)
        mime = "text/csv; charset=utf-8"
    elif fmt == "json":
        filename = f"sleepnova_{safe_period}_report_{stamp}.json"
        target = out_dir / filename
        content = export_json(report["records"], output_path=target)
        mime = "application/json; charset=utf-8"
    elif fmt in ("txt", "text", "audit"):
        filename = f"sleepnova_{safe_period}_audit_{stamp}.txt"
        target = out_dir / filename
        content = render_txt_audit_log(report)
        target.write_text(content, encoding="utf-8")
        mime = "text/plain; charset=utf-8"
    elif fmt == "png":
        chart_kind = "monthly_trend" if safe_period in ("monthly", "all") else "weekly_trend"
        filename = f"sleepnova_{safe_period}_chart_{stamp}.png"
        target = out_dir / filename
        chart_meta = generate_sleep_chart(records, settings, chart_kind=chart_kind, output_path=target)
        return {
            "filename": target.name,
            "path": str(target),
            "mime": "image/png",
            "is_binary": True,
            "engine": chart_meta["engine"],
            "report": report,
        }
    else:
        filename = f"sleepnova_{safe_period}_report_{stamp}.md"
        target = out_dir / filename
        content = render_markdown_report(report)
        target.write_text(content, encoding="utf-8")
        mime = "text/markdown; charset=utf-8"

    return {
        "filename": filename,
        "path": str(target),
        "mime": mime,
        "is_binary": False,
        "content": content,
        "report": report,
    }
