"""Unit tests for SleepNova multi-format report exports and PNG chart generation."""

from pathlib import Path
import tempfile
import unittest

import config
from backend.plotting import generate_sleep_chart
from backend.reports import export_report_file
from backend.storage import build_demo_dataset


class TestReports(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.out_dir = Path(self.tmp.name)
        self.records = build_demo_dataset()
        self.settings = dict(config.DEFAULT_SETTINGS)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_export_all_report_formats(self) -> None:
        for fmt in ("csv", "json", "markdown", "txt", "png"):
            res = export_report_file(
                self.records,
                self.settings,
                period="weekly",
                export_format=fmt,
                output_dir=self.out_dir,
            )
            exported_file = Path(res["path"])
            self.assertTrue(exported_file.exists(), f"Missing exported {fmt} file")
            self.assertGreater(exported_file.stat().st_size, 0)

    def test_png_chart_signature(self) -> None:
        out_png = self.out_dir / "test_chart.png"
        meta = generate_sleep_chart(
            self.records,
            self.settings,
            chart_kind="monthly_trend",
            output_path=out_png,
        )
        self.assertTrue(out_png.exists())
        header = out_png.read_bytes()[:8]
        self.assertEqual(header, b"\x89PNG\r\n\x1a\n")
        self.assertIn(meta["engine"], ("matplotlib", "stdlib_png_fallback"))


if __name__ == "__main__":
    unittest.main()
