"""Unit tests for SleepNova CSV/JSON persistence, corruption recovery, search, and bulk CSV import."""

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from backend.storage import (
    ValidationError,
    delete_record,
    import_csv,
    load_records,
    save_record,
    search_records,
    update_record,
)


class TestStorage(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.json_path = self.dir / "sleep_records.json"
        self.csv_path = self.dir / "sleep_records.csv"

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_missing_file_initialization_and_crud_persistence(self) -> None:
        initial = load_records(json_path=self.json_path, csv_path=self.csv_path)
        self.assertEqual(initial, [])
        self.assertTrue(self.json_path.exists())
        self.assertTrue(self.csv_path.exists())

        saved = save_record(
            {
                "sleep_date": "2026-11-15",
                "bedtime": "23:00",
                "wake_date": "2026-11-16",
                "wake_time": "07:00",
                "notes": "Persisted session",
            },
            json_path=self.json_path,
            csv_path=self.csv_path,
            allow_future=True,
        )
        reloaded = load_records(json_path=self.json_path, csv_path=self.csv_path)
        self.assertEqual(len(reloaded), 1)
        self.assertEqual(reloaded[0]["id"], saved["id"])

        updated = update_record(
            saved["id"],
            {
                "sleep_date": "2026-11-15",
                "bedtime": "22:30",
                "wake_date": "2026-11-16",
                "wake_time": "07:00",
                "notes": "Updated session",
            },
            json_path=self.json_path,
            csv_path=self.csv_path,
            allow_future=True,
        )
        self.assertEqual(updated["duration_minutes"], 510)

        search_res = search_records(
            keyword="Updated",
            json_path=self.json_path,
            csv_path=self.csv_path,
        )
        self.assertEqual(search_res["total"], 1)

        delete_record(saved["id"], json_path=self.json_path, csv_path=self.csv_path)
        self.assertEqual(load_records(json_path=self.json_path, csv_path=self.csv_path), [])

    def test_corrupted_json_preserves_backup_and_recovers_from_csv(self) -> None:
        save_record(
            {
                "sleep_date": "2026-11-14",
                "bedtime": "22:45",
                "wake_date": "2026-11-15",
                "wake_time": "06:45",
                "notes": "CSV backup test",
            },
            json_path=self.json_path,
            csv_path=self.csv_path,
            allow_future=True,
        )
        # Corrupt the JSON file intentionally
        self.json_path.write_text("{corrupted_json: [", encoding="utf-8")

        meta = load_records(json_path=self.json_path, csv_path=self.csv_path, include_meta=True)
        assert isinstance(meta, dict)
        self.assertEqual(len(meta["records"]), 1)
        self.assertIn("recovered", meta["recovery_notice"].lower())
        backups = list(self.dir.glob("sleep_records.json.corrupted.*"))
        self.assertEqual(len(backups), 1)

    def test_bulk_csv_import_row_by_row_validation(self) -> None:
        csv_text = (
            "sleep_date,bedtime,wake_date,wake_time,notes\n"
            "2026-11-01,22:30,2026-11-02,06:30,Good row 1\n"
            "2026-11-02,10:45 PM,2026-11-03,6:45 AM,Good row 2\n"
            "2026-11-01,22:30,2026-11-02,06:30,Duplicate row\n"
            "bad-date,22:30,2026-11-04,06:30,Bad date row\n"
            "2026-11-04,23:00,2026-11-04,06:00,Negative duration row\n"
        )
        res = import_csv(
            csv_text,
            json_path=self.json_path,
            csv_path=self.csv_path,
            allow_future=True,
        )
        self.assertEqual(res["total_rows"], 5)
        self.assertEqual(res["imported_count"], 2)
        self.assertEqual(res["rejected_count"], 3)
        self.assertEqual(res["duplicate_count"], 1)
        self.assertEqual(res["invalid_count"], 2)
        self.assertEqual(len(res["error_logs"]), 3)
        self.assertEqual(res["error_logs"][0]["category"], "duplicate")
        self.assertEqual(res["error_logs"][1]["category"], "invalid")

    def test_bulk_csv_import_rejects_oversized_payload(self) -> None:
        oversized = "sleep_date,bedtime,wake_date,wake_time,notes\n" + ("a" * 2_200_000)
        with self.assertRaises(ValidationError):
            import_csv(
                oversized,
                json_path=self.json_path,
                csv_path=self.csv_path,
                allow_future=True,
            )

    def test_load_records_handles_permission_error_safely(self) -> None:
        self.json_path.write_text("[]", encoding="utf-8")
        self.csv_path.write_text("id,sleep_date,bedtime,wake_date,wake_time,duration_minutes,duration_hours,notes,is_demo,created_at,updated_at\n", encoding="utf-8")
        with patch.object(Path, "read_text", side_effect=PermissionError("Read denied")):
            meta = load_records(json_path=self.json_path, csv_path=self.csv_path, include_meta=True)
        assert isinstance(meta, dict)
        self.assertEqual(meta["records"], [])
        self.assertIsNotNone(meta["recovery_notice"])
        self.assertIn("permission", meta["recovery_notice"].lower())


if __name__ == "__main__":
    unittest.main()
