"""Unit tests for SleepNova sleep duration calculations and domain logic."""

import unittest

from backend.sleep_logic import (
    calculate_duration,
    compute_bedtime_offset_minutes,
    create_record_object,
    format_duration,
)


class TestSleepLogic(unittest.TestCase):
    def test_standard_overnight_duration(self) -> None:
        res = calculate_duration("2026-11-20", "22:30", "2026-11-21", "06:30")
        self.assertEqual(res["duration_minutes"], 480)
        self.assertEqual(res["duration_hours"], 8.0)
        self.assertEqual(res["formatted"], "8h 00m")
        self.assertTrue(res["crosses_midnight"])

    def test_same_day_nap_duration(self) -> None:
        res = calculate_duration("2026-11-20", "01:15", "2026-11-20", "08:45")
        self.assertEqual(res["duration_minutes"], 450)
        self.assertEqual(res["duration_hours"], 7.5)
        self.assertFalse(res["crosses_midnight"])

    def test_zero_and_negative_durations_rejected(self) -> None:
        with self.assertRaises(ValueError):
            calculate_duration("2026-11-20", "07:00", "2026-11-20", "07:00")
        with self.assertRaises(ValueError):
            calculate_duration("2026-11-20", "23:00", "2026-11-20", "06:00")

    def test_bedtime_midnight_offset_continuity(self) -> None:
        self.assertEqual(compute_bedtime_offset_minutes("23:30"), -30)
        self.assertEqual(compute_bedtime_offset_minutes("00:30"), 30)
        self.assertEqual(compute_bedtime_offset_minutes("00:00"), 0)

    def test_format_duration(self) -> None:
        self.assertEqual(format_duration(495), "8h 15m")
        self.assertEqual(format_duration(0), "0h 00m")

    def test_create_record_object(self) -> None:
        rec = create_record_object("2026-11-20", "22:45", "2026-11-21", "06:15", notes="Rested")
        self.assertTrue(rec.id.startswith("SLP-20261120-"))
        self.assertEqual(rec.duration_minutes, 450)
        self.assertEqual(rec.notes, "Rested")


if __name__ == "__main__":
    unittest.main()
